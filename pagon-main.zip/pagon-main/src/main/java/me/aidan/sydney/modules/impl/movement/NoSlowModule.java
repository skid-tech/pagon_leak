package me.aidan.sydney.modules.impl.movement;

import me.aidan.sydney.Sydney;
import me.aidan.sydney.events.SubscribeEvent;
import me.aidan.sydney.events.impl.*;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;
import me.aidan.sydney.settings.impl.BooleanSetting;
import me.aidan.sydney.settings.impl.ModeSetting;
import me.aidan.sydney.utils.minecraft.NetworkUtils;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicBoolean;

@RegisterModule(name = "NoSlow", description = "Removes slowness effects from various actions with multiple bypass modes.", category = Module.Category.MOVEMENT)
public class NoSlowModule extends Module {
    
    // Core Settings
    public ModeSetting mode = new ModeSetting("Mode", "NoSlow bypass mode for different anticheats.", "Vanilla", new String[]{
        "Vanilla", "NCP", "Grim", "GrimPacket", "Drop", "None"
    });
    
    // Legacy items setting for compatibility
    public BooleanSetting items = new BooleanSetting("Items", "Removes slowness from using items.", true);
    
    // Block Slowdowns
    public BooleanSetting soulSand = new BooleanSetting("SoulSand", "Removes slowness from soul sand.", true);
    public BooleanSetting slimeBlocks = new BooleanSetting("SlimeBlocks", "Removes slowness from slime blocks.", false);
    public BooleanSetting honeyBlocks = new BooleanSetting("HoneyBlocks", "Removes slowness from honey blocks.", false);
    
    // Movement Settings
    public BooleanSetting sneak = new BooleanSetting("Sneak", "Bypass sneak slowdown.", false);
    public BooleanSetting climb = new BooleanSetting("Climb", "Bypass ladder/vine slowdown.", false);
    
    // GUI Movement
    public BooleanSetting guiMove = new BooleanSetting("GuiMove", "Allows movement while in GUI screens.", true);
    public BooleanSetting allowSneak = new BooleanSetting("AllowSneak", "Allow sneaking in GUI.", new BooleanSetting.Visibility(guiMove, true), false);
    
    // GUI Click Bypass
    public ModeSetting clickBypass = new ModeSetting("GuiClickBypass", "Bypass for clicking in GUI while moving.", new BooleanSetting.Visibility(guiMove, true), "None", new String[]{
        "None", "NCP", "NCP2", "Grim", "Delay"
    });
    
    // Internal state
    private final Queue<ClickSlotC2SPacket> storedClicks = new LinkedList<>();
    private final AtomicBoolean pauseClicks = new AtomicBoolean(false);
    private boolean wasUsingItem = false;
    private int itemUseDelay = 0;

    @Override
    public String getMetaData() {
        return mode.getValue();
    }

    @SubscribeEvent
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) return;

        wasUsingItem = mc.player.isUsingItem();
        itemUseDelay--;
        
        if (wasUsingItem) {
            itemUseDelay = 2;
        }

        // Apply NoSlow bypass based on mode
        if (items.getValue() && wasUsingItem && !mc.player.isRiding() && !mc.player.isGliding()) {
            switch (mode.getValue()) {
                case "NCP":
                    // NCP bypass - send slot update
                    mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().selectedSlot));
                    break;
                    
                case "Grim":
                    // Grim bypass - interact with opposite hand
                    if (mc.player.getActiveHand() == Hand.OFF_HAND) {
                        NetworkUtils.sendSequencedPacket(id -> new PlayerInteractItemC2SPacket(
                            Hand.MAIN_HAND, id, 
                            Sydney.ROTATION_MANAGER.getServerYaw(), 
                            Sydney.ROTATION_MANAGER.getServerPitch()
                        ));
                    } else {
                        NetworkUtils.sendSequencedPacket(id -> new PlayerInteractItemC2SPacket(
                            Hand.OFF_HAND, id, 
                            Sydney.ROTATION_MANAGER.getServerYaw(), 
                            Sydney.ROTATION_MANAGER.getServerPitch()
                        ));
                    }
                    break;
                    
                case "GrimPacket":
                    // GrimPacket bypass - click slot + interact
                    mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, 1, 0, SlotActionType.PICKUP, mc.player);
                    if (mc.player.getActiveHand() == Hand.OFF_HAND) {
                        NetworkUtils.sendSequencedPacket(id -> new PlayerInteractItemC2SPacket(
                            Hand.MAIN_HAND, id, 
                            Sydney.ROTATION_MANAGER.getServerYaw(), 
                            Sydney.ROTATION_MANAGER.getServerPitch()
                        ));
                    } else {
                        NetworkUtils.sendSequencedPacket(id -> new PlayerInteractItemC2SPacket(
                            Hand.OFF_HAND, id, 
                            Sydney.ROTATION_MANAGER.getServerYaw(), 
                            Sydney.ROTATION_MANAGER.getServerPitch()
                        ));
                    }
                    break;
            }
        }

        // GUI Movement
        if (guiMove.getValue() && mc.currentScreen != null && !(mc.currentScreen instanceof ChatScreen)) {
            updateKeyBindings();
        }
    }

    @SubscribeEvent
    public void onKeyboardInput(KeyboardInputEvent event) {
        if (mc.player == null || mc.world == null) return;

        // Cancel sneak slowdown
        if (sneak.getValue()) {
            event.setCancelled(true);
        }

        // GUI Movement keyboard handling
        if (guiMove.getValue() && mc.currentScreen != null && !(mc.currentScreen instanceof ChatScreen)) {
            updateKeyBindings();
        }
    }

    @SubscribeEvent
    public void onInteractItem(InteractItemEvent event) {
        if (mc.player == null || mc.world == null) return;

        // Handle item use cooldown
        if (itemUseDelay > 0) {
            event.setCancelled(true);
        } else if (mode.getValue().equals("GrimPacket") && 
                   mc.player.getStackInHand(event.getHand()).getItem().getComponents().contains(DataComponentTypes.FOOD)) {
            // GrimPacket food bypass
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, 1, 0, SlotActionType.PICKUP, mc.player);
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketSendEvent event) {
        if (mc.player == null || mc.world == null) return;

        // Drop mode bypass
        if (mode.getValue().equals("Drop") && event.getPacket() instanceof PlayerInteractItemC2SPacket packet) {
            if (packet.getHand() == Hand.MAIN_HAND && 
                mc.player.getMainHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD)) {
                mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                    PlayerActionC2SPacket.Action.DROP_ITEM, 
                    BlockPos.ORIGIN, 
                    Direction.DOWN
                ));
            }
        }

        // GUI Click Bypass handling
        if (!isMoving() || pauseClicks.get()) {
            return;
        }

        if (event.getPacket() instanceof ClickSlotC2SPacket clickPacket) {
            switch (clickBypass.getValue()) {
                case "Grim":
                    // Grim bypass - close screen for non-pickup actions
                    if (clickPacket.getActionType() != SlotActionType.PICKUP && 
                        clickPacket.getActionType() != SlotActionType.PICKUP_ALL) {
                        mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
                    }
                    break;

                case "NCP":
                    // NCP bypass - send position packet
                    if (mc.player.isOnGround() && 
                        !mc.world.getBlockCollisions(mc.player, 
                            mc.player.getBoundingBox().offset(0.0, 0.0656, 0.0)).iterator().hasNext()) {
                        
                        if (mc.player.isSprinting()) {
                            mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(
                                mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING
                            ));
                        }
                        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                            mc.player.getX(), 
                            mc.player.getY() + 0.0656, 
                            mc.player.getZ(), 
                            false,
                            mc.player.horizontalCollision
                        ));
                    }
                    break;

                case "NCP2":
                    // NCP2 bypass - smaller position offset
                    if (mc.player.isOnGround() && 
                        !mc.world.getBlockCollisions(mc.player, 
                            mc.player.getBoundingBox().offset(0.0, 0.000000271875, 0.0)).iterator().hasNext()) {
                        
                        if (mc.player.isSprinting()) {
                            mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(
                                mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING
                            ));
                        }
                        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                            mc.player.getX(), 
                            mc.player.getY() + 0.000000271875, 
                            mc.player.getZ(), 
                            false,
                            mc.player.horizontalCollision
                        ));
                    }
                    break;

                case "Delay":
                    // Delay bypass - store clicks and send later
                    storedClicks.add(clickPacket);
                    event.setCancelled(true);
                    break;
            }
        }

        // Handle stored clicks on screen close
        if (event.getPacket() instanceof CloseHandledScreenC2SPacket) {
            if (clickBypass.getValue().equals("Delay")) {
                pauseClicks.set(true);
                while (!storedClicks.isEmpty()) {
                    mc.getNetworkHandler().sendPacket(storedClicks.poll());
                }
                pauseClicks.set(false);
            }
        }
    }

    @SubscribeEvent
    public void onPacketSendPost(PacketSendEvent.Post event) {
        if (mc.player == null) return;

        // Restore sprint after NCP click bypass
        if (event.getPacket() instanceof ClickSlotC2SPacket) {
            if (mc.player.isSprinting() && clickBypass.getValue().equals("NCP")) {
                mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(
                    mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING
                ));
            }
        }
    }

    @Override
    public void onDisable() {
        storedClicks.clear();
        pauseClicks.set(false);
        wasUsingItem = false;
        itemUseDelay = 0;
    }

    /**
     * Check if NoSlow should be applied (legacy compatibility)
     */
    public boolean shouldSlow() {
        if (!isToggled()) return true;
        if (!items.getValue()) return true;
        if (mode.getValue().equals("None")) return true;
        if (mode.getValue().equals("Drop") || mode.getValue().equals("GrimPacket")) {
            return !wasUsingItem;
        }
        return false;
    }

    /**
     * Check if player is moving
     */
    private boolean isMoving() {
        if (mc.player == null) return false;
        return mc.player.input.movementForward != 0.0f || mc.player.input.movementSideways != 0.0f;
    }

    /**
     * Update key bindings for GUI movement
     */
    private void updateKeyBindings() {
        KeyBinding[] movementKeys = {
            mc.options.forwardKey,
            mc.options.backKey,
            mc.options.leftKey,
            mc.options.rightKey,
            mc.options.jumpKey,
            mc.options.sprintKey
        };

        for (KeyBinding key : movementKeys) {
            key.setPressed(InputUtil.isKeyPressed(
                mc.getWindow().getHandle(), 
                InputUtil.fromTranslationKey(key.getBoundKeyTranslationKey()).getCode()
            ));
        }

        if (allowSneak.getValue()) {
            mc.options.sneakKey.setPressed(InputUtil.isKeyPressed(
                mc.getWindow().getHandle(), 
                InputUtil.fromTranslationKey(mc.options.sneakKey.getBoundKeyTranslationKey()).getCode()
            ));
        }
    }
}
