package me.aidan.sydney.managers;

import lombok.Getter;
import me.aidan.sydney.Sydney;
import me.aidan.sydney.events.SubscribeEvent;
import me.aidan.sydney.events.impl.*;
import me.aidan.sydney.mixins.accessors.EntityAccessor;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.impl.core.RotationsModule;
import me.aidan.sydney.utils.IMinecraft;
import me.aidan.sydney.utils.animations.Easing;
import me.aidan.sydney.utils.rotations.Rotation;
import me.aidan.sydney.utils.system.MathUtils;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import static java.lang.Integer.MAX_VALUE;
import static java.lang.Integer.MIN_VALUE;

public class RotationManager implements IMinecraft {
    private final List<Rotation> requests = new CopyOnWriteArrayList<>();
    
    @Getter private Rotation rotation = null;
    
    // Server rotation tracking
    @Getter private float serverYaw;
    @Getter private float serverPitch;
    private float lastServerYaw;
    private float lastServerPitch;
    
    // Movement fix tracking
    private float prevFixYaw;
    private float prevYaw;
    private float prevPitch;
    private float prevJumpYaw;
    
    // Render tracking
    private float prevRenderYaw, prevRenderPitch;
    private long lastRenderTime = 0L;
    
    // Rotation state
    private boolean rotate;
    private int rotateTicks;
    
    // YawStep state - CRITICAL for Grim AC
    @Getter private boolean rotated = true; // Whether we've finished rotating to target
    private Rotation targetRotation = null; // The rotation we're stepping towards
    
    // Web jump fix for Grim
    private boolean webJumpFix;
    private boolean preJumpFix;

    private static final HashMap<String, Integer> PRIORITIES = new HashMap<>();
    static {
        PRIORITIES.put("KillAura", 1);
        PRIORITIES.put("AutoCrystal", 2);
        PRIORITIES.put("SpeedMine", 3);
        PRIORITIES.put("SelfFill", 4);
    }

    public RotationManager() {
        Sydney.EVENT_HANDLER.subscribe(this);
    }

    @SubscribeEvent
    public void onPacketSend(PacketSendEvent event) {
        if (mc.player == null || mc.world == null) return;

        if (event.getPacket() instanceof PlayerMoveC2SPacket packet) {
            // Update server rotation tracking for ALL movement packets
            // Not just when look changes - this is critical for Grim AC
            if (packet.changesLook()) {
                float packetYaw = packet.getYaw(mc.player.getYaw());
                float packetPitch = packet.getPitch(mc.player.getPitch());
                
                lastServerYaw = serverYaw;
                lastServerPitch = serverPitch;
                serverYaw = packetYaw;
                serverPitch = packetPitch;
            } else {
                // Even if look doesn't change, ensure server rotation is synced
                // Grim uses rotation for movement prediction
                if (serverYaw == 0.0f && serverPitch == 0.0f) {
                    serverYaw = mc.player.getYaw();
                    serverPitch = mc.player.getPitch();
                }
            }
        }
    }

    @SubscribeEvent(priority = MIN_VALUE)
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        // Check for web jump fix requirement
        webJumpFix = me.aidan.sydney.utils.minecraft.EntityUtils.isInWeb(mc.player);
        
        // Clean up old rotation requests
        requests.removeIf(rot -> System.currentTimeMillis() - rot.getTime() > 100);

        if (requests.isEmpty()) {
            // No new requests - check if we should clear rotation
            if (rotation != null && isDoneRotating()) {
                rotation = null;
            }
            return;
        }
        
        // Get the highest priority rotation request
        Rotation request = getRotationRequest();
        if (request == null) {
            // No valid request but we have requests (shouldn't happen)
            if (isDoneRotating()) {
                rotation = null;
            }
            return;
        }
        
        // Apply new rotation
        rotation = request;
        rotateTicks = 0;
        rotate = true;
    }

    @SubscribeEvent
    public void onPlayerUpdate$POST(PlayerUpdateEvent.Post event) {
        // Track last server rotations for smooth interpolation
        if (mc.player != null && rotation != null) {
            lastServerYaw = serverYaw;
            lastServerPitch = serverPitch;
        }
    }

    @SubscribeEvent
    public void onMovementPackets(MovementPacketsEvent event) {
        if (rotation == null) {
            rotated = true;
            targetRotation = null;
            return;
        }

        if (rotate) {
            // Remove the rotation request now that we're applying it
            removeRotation(rotation);
            
            // Check if YawStep is being used and we have a target rotation
            if (targetRotation != null) {
                // YawStep mode: gradually rotate towards target
                float targetYaw = targetRotation.getYaw();
                float targetPitch = targetRotation.getPitch();
                
                float currentYaw = serverYaw;
                float diff = MathHelper.wrapDegrees(targetYaw - currentYaw);
                float absDiff = Math.abs(diff);
                
                // Get the yaw step limit from AutoCrystal settings
                float yawLimit = 180.0f; // Default - instant rotation
                me.aidan.sydney.modules.impl.combat.AutoCrystalModule acModule = Sydney.MODULE_MANAGER.getModule(me.aidan.sydney.modules.impl.combat.AutoCrystalModule.class);
                if (acModule != null && acModule.yawStep != null && acModule.yawStep.getValue() && acModule.yawStepThreshold != null) {
                    yawLimit = acModule.yawStepThreshold.getValue().floatValue();
                }
                
                if (absDiff > yawLimit && yawLimit < 180.0f) {
                    // Not done rotating - step towards target
                    int dir = diff > 0.0f ? 1 : -1;
                    float deltaYaw = dir * yawLimit;
                    float newYaw = currentYaw + deltaYaw;
                    
                    event.setYaw(newYaw);
                    event.setPitch(targetPitch); // Pitch can be set immediately
                    event.setCancelled(true);
                    rotated = false; // NOT done rotating
                } else {
                    // Done rotating - set to exact target
                    event.setYaw(targetYaw);
                    event.setPitch(targetPitch);
                    event.setCancelled(true);
                    rotated = true; // Done rotating
                    targetRotation = null;
                }
            } else {
                // Normal rotation mode: instant rotation
                event.setYaw(rotation.getYaw());
                event.setPitch(rotation.getPitch());
                event.setCancelled(true);
                rotated = true; // Always rotated in normal mode
                targetRotation = null;
            }
            
            rotate = false;
            rotateTicks = 0; // Reset preservation counter
        } else {
            // Increment preservation ticks
            rotateTicks++;
        }

        // If this is a snap rotation, clear it immediately after application
        if (rotation != null && rotation.isSnap() && rotated) {
            rotation = null;
            targetRotation = null;
        }
    }

    @SubscribeEvent(priority = MAX_VALUE)
    public void onUpdateMovement(UpdateMovementEvent event) {
        if (rotation == null) return;

        prevYaw = mc.player.getYaw();
        prevPitch = mc.player.getPitch();

        mc.player.setYaw(rotation.getYaw());
        mc.player.setPitch(rotation.getPitch());
        
        lastRenderTime = System.currentTimeMillis();
    }

    @SubscribeEvent(priority = MIN_VALUE)
    public void onUpdateMovement$POST(UpdateMovementEvent.Post event) {
        if (rotation == null) return;

        mc.player.setYaw(prevYaw);
        mc.player.setPitch(prevPitch);
    }

    @SubscribeEvent
    public void onUpdateVelocity(UpdateVelocityEvent event) {
        if (mc.player == null) return;
        
        RotationsModule rotModule = Sydney.MODULE_MANAGER.getModule(RotationsModule.class);
        if (rotModule == null || !rotModule.movementFix.getValue()) return;
        if (rotation == null) return;

        event.setVelocity(movementInputToVelocity(rotation.getYaw(), event.getMovementInput(), event.getSpeed()));
        event.setCancelled(true);
    }

    @SubscribeEvent
    public void onKeyboardTick(KeyboardTickEvent event) {
        if (mc.player == null || mc.world == null || mc.player.isRiding()) return;
        
        RotationsModule rotModule = Sydney.MODULE_MANAGER.getModule(RotationsModule.class);
        if (rotModule == null || !rotModule.movementFix.getValue()) return;
        if (rotation == null) return;

        float movementForward = event.getMovementForward();
        float movementSideways = event.getMovementSideways();

        float delta = (mc.player.getYaw() - rotation.getYaw()) * MathHelper.RADIANS_PER_DEGREE;

        float cos = MathHelper.cos(delta);
        float sin = MathHelper.sin(delta);

        event.setMovementForward(Math.round(movementForward * cos + movementSideways * sin));
        event.setMovementSideways(Math.round(movementSideways * cos - movementForward * sin));
        event.setCancelled(true);
    }

    @SubscribeEvent
    public void onPlayerJump(PlayerJumpEvent event) {
        if (mc.player == null || mc.world == null || mc.player.isRiding()) return;
        
        RotationsModule rotModule = Sydney.MODULE_MANAGER.getModule(RotationsModule.class);
        if (rotModule == null || !rotModule.movementFix.getValue()) return;
        if (rotation == null) return;

        prevJumpYaw = mc.player.getYaw();
        mc.player.setYaw(rotation.getYaw());
        
        // Web jump fix for Grim - prevents sprint flags
        if (rotModule.webJumpFix.getValue() && webJumpFix) {
            preJumpFix = mc.player.isSprinting();
            mc.player.setSprinting(false);
        }
    }

    @SubscribeEvent
    public void onPlayerJump$POST(PlayerJumpEvent.Post event) {
        if (mc.player == null || mc.world == null || mc.player.isRiding()) return;
        
        RotationsModule rotModule = Sydney.MODULE_MANAGER.getModule(RotationsModule.class);
        if (rotModule == null || !rotModule.movementFix.getValue()) return;
        if (rotation == null) return;

        mc.player.setYaw(prevJumpYaw);
        
        // Restore sprint state after web jump
        if (webJumpFix) {
            mc.player.setSprinting(preJumpFix);
        }
    }

    public void rotate(float[] rotations, int priority) {
        rotate(rotations[0], rotations[1], priority);
    }

    public void rotate(float yaw, float pitch, int priority) {
        rotate(yaw, pitch, priority, false);
    }

    public void rotate(float yaw, float pitch, int priority, boolean snap) {
        // Clamp pitch to valid range
        pitch = MathHelper.clamp(pitch, -90.0f, 90.0f);
        
        // Create rotation with priority
        Rotation newRotation = new Rotation(yaw, pitch, priority, snap);
        
        // Apply sensitivity correction using Kami's method
        RotationsModule rotModule = Sydney.MODULE_MANAGER.getModule(RotationsModule.class);
        if (rotModule != null && rotModule.mouseSensFix.getValue()) {
            newRotation = newRotation.fix();
        }
        
        // If MAX_VALUE priority, set as current rotation immediately
        if (priority == MAX_VALUE) {
            this.rotation = newRotation;
            // Snap rotations are always instant (no stepping)
            if (!snap) {
                this.targetRotation = newRotation;
                this.rotated = false; // Start rotation stepping
            } else {
                this.targetRotation = null;
                this.rotated = true; // Instant rotation
            }
            rotate = true;
        }
        
        // Check if request with same priority exists
        Rotation existing = requests.stream()
                .filter(r -> r.getPriority() == priority && r.getModule() == null)
                .findFirst()
                .orElse(null);
        
        if (existing != null) {
            // Update existing request
            existing.setYaw(newRotation.getYaw());
            existing.setPitch(newRotation.getPitch());
            existing.setSnap(snap);
        } else {
            // Add new request
            requests.add(newRotation);
        }
    }

    public void rotate(float[] rotations, Module module) {
        rotate(rotations[0], rotations[1], module);
    }

    public void rotate(float yaw, float pitch, Module module) {
        rotate(yaw, pitch, module, getModulePriority(module), false);
    }

    public void rotate(float[] rotations, Module module, int priority) {
        rotate(rotations[0], rotations[1], module, priority);
    }

    public void rotate(float yaw, float pitch, Module module, int priority) {
        rotate(yaw, pitch, module, priority, false);
    }

    public void rotate(float yaw, float pitch, Module module, int priority, boolean snap) {
        // Clamp pitch to valid range
        pitch = MathHelper.clamp(pitch, -90.0f, 90.0f);
        
        // Create rotation with module and priority
        Rotation newRotation = new Rotation(yaw, pitch, module, priority, snap);
        
        // Apply sensitivity correction using Kami's method
        RotationsModule rotModule = Sydney.MODULE_MANAGER.getModule(RotationsModule.class);
        if (rotModule != null && rotModule.mouseSensFix.getValue()) {
            newRotation = newRotation.fix();
        }
        
        // If MAX_VALUE priority, set as current rotation immediately
        if (priority == MAX_VALUE) {
            this.rotation = newRotation;
            // Snap rotations are always instant (no stepping)
            if (!snap) {
                this.targetRotation = newRotation;
                this.rotated = false; // Start rotation stepping
            } else {
                this.targetRotation = null;
                this.rotated = true; // Instant rotation
            }
            rotate = true;
        }
        
        // Check if request from same module exists
        Rotation existing = requests.stream()
                .filter(r -> r.getModule() == module)
                .findFirst()
                .orElse(null);
        
        if (existing != null) {
            // Update existing request
            existing.setYaw(newRotation.getYaw());
            existing.setPitch(newRotation.getPitch());
            existing.setSnap(snap);
        } else {
            // Add new request
            requests.add(newRotation);
        }
    }

    /**
     * Kami-style rotateTo method - applies fix() and manages rotation queue
     * This is the main rotation entry point used by Kami
     */
    public void rotateTo(Rotation in) {
        // Apply sensitivity correction fix
        Rotation fixedRotation = in.fix();
        
        // If MAX_VALUE priority, set as current rotation immediately (Kami behavior)
        if (fixedRotation.getPriority() == MAX_VALUE) {
            this.rotation = fixedRotation;
            // Snap rotations are always instant (no stepping)
            if (!fixedRotation.isSnap()) {
                this.targetRotation = fixedRotation;
                this.rotated = false; // Start rotation stepping
            } else {
                this.targetRotation = null;
                this.rotated = true; // Instant rotation
            }
            rotate = true;
        }
        
        // Find existing request with same priority
        Rotation request = requests.stream()
                .filter(r -> fixedRotation.getPriority() == r.getPriority())
                .findFirst()
                .orElse(null);
        
        if (request == null) {
            requests.add(fixedRotation);
        } else {
            // Update existing request
            request.setYaw(fixedRotation.getYaw());
            request.setPitch(fixedRotation.getPitch());
        }
    }

    /**
     * Silent rotation via packet - doesn't affect client visuals
     * Now with Kami's GCD sensitivity correction for Grim compatibility
     */
    public void setRotationSilent(float yaw, float pitch) {
        // Wrap yaw to valid range
        yaw = MathHelper.wrapDegrees(yaw);
        pitch = MathHelper.clamp(pitch, -90.0f, 90.0f);
        
        // Create rotation and apply sensitivity correction
        Rotation newRotation = new Rotation(yaw, pitch, MAX_VALUE, true);
        
        RotationsModule rotModule = Sydney.MODULE_MANAGER.getModule(RotationsModule.class);
        if (rotModule != null && rotModule.mouseSensFix.getValue()) {
            newRotation = newRotation.fix();
        }
        
        this.rotation = newRotation;
        rotate = true;
        
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                Sydney.POSITION_MANAGER.getServerX(), 
                Sydney.POSITION_MANAGER.getServerY(), 
                Sydney.POSITION_MANAGER.getServerZ(), 
                newRotation.getYaw(), newRotation.getPitch(), 
                Sydney.POSITION_MANAGER.isServerOnGround(), 
                mc.player.horizontalCollision
        ));
        
        // Update server rotation tracking
        lastServerYaw = serverYaw;
        lastServerPitch = serverPitch;
        serverYaw = newRotation.getYaw();
        serverPitch = newRotation.getPitch();
    }

    /**
     * Sync rotation with server - required for Grim rotation movement checks
     */
    public void setRotationSilentSync() {
        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        rotate(yaw, pitch, MAX_VALUE, true);
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                Sydney.POSITION_MANAGER.getServerX(), 
                Sydney.POSITION_MANAGER.getServerY(), 
                Sydney.POSITION_MANAGER.getServerZ(), 
                yaw, pitch, 
                Sydney.POSITION_MANAGER.isServerOnGround(), 
                mc.player.horizontalCollision
        ));
    }

    /**
     * Direct packet rotation without going through rotation queue
     * Now with Kami's GCD sensitivity correction for Grim compatibility
     */
    public void packetRotate(float[] rotations) {
        packetRotate(rotations[0], rotations[1]);
    }

    public void packetRotate(float yaw, float pitch) {
        // Wrap yaw to valid range (-180 to 180)
        yaw = MathHelper.wrapDegrees(yaw);
        pitch = MathHelper.clamp(pitch, -90.0f, 90.0f);
        
        // Create rotation and apply sensitivity correction
        Rotation newRotation = new Rotation(yaw, pitch, MAX_VALUE, true);
        
        RotationsModule rotModule = Sydney.MODULE_MANAGER.getModule(RotationsModule.class);
        if (rotModule != null && rotModule.mouseSensFix.getValue()) {
            newRotation = newRotation.fix();
        }
        
        if (serverYaw == newRotation.getYaw() && serverPitch == newRotation.getPitch()) return;
        
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                Sydney.POSITION_MANAGER.getServerX(), 
                Sydney.POSITION_MANAGER.getServerY(), 
                Sydney.POSITION_MANAGER.getServerZ(), 
                newRotation.getYaw(), newRotation.getPitch(), 
                Sydney.POSITION_MANAGER.isServerOnGround(), 
                mc.player.horizontalCollision
        ));
        
        // Update server rotation tracking
        lastServerYaw = serverYaw;
        lastServerPitch = serverPitch;
        serverYaw = newRotation.getYaw();
        serverPitch = newRotation.getPitch();
    }

    /**
     * Set client yaw and pitch directly (visual only)
     */
    public void setRotationClient(float yaw, float pitch) {
        if (mc.player == null) return;
        mc.player.setYaw(yaw);
        mc.player.setPitch(MathHelper.clamp(pitch, -90.0f, 90.0f));
    }

    public boolean removeRotation(Rotation request) {
        return requests.remove(request);
    }

    public boolean isRotationBlocked(int priority) {
        return rotation != null && priority < rotation.getPriority();
    }
    
    /**
     * Check if rotation is blocked OR if we're still rotating (YawStep)
     * CRITICAL for Grim AC - don't execute actions while rotating
     */
    public boolean isRotationBlockedOrStepping() {
        return rotation != null && !rotated;
    }

    public boolean isDoneRotating() {
        RotationsModule rotModule = Sydney.MODULE_MANAGER.getModule(RotationsModule.class);
        if (rotModule == null) return false;
        return rotateTicks > rotModule.preserveTicks.getValue().intValue();
    }

    public boolean isRotating() {
        return rotation != null;
    }

    public boolean inRenderTime() {
        return System.currentTimeMillis() - lastRenderTime < 1000;
    }

    public float getRotationYaw() {
        return rotation != null ? rotation.getYaw() : mc.player.getYaw();
    }

    public float getRotationPitch() {
        return rotation != null ? rotation.getPitch() : mc.player.getPitch();
    }

    public float getWrappedYaw() {
        return MathHelper.wrapDegrees(serverYaw);
    }

    /**
     * Get rotation vector from current rotation
     * Used for raycasting and accurate look direction
     * Kami RotationManager method
     */
    public Vec3d getRotationVector() {
        if (rotation == null) return null;

        float f = rotation.getPitch() * 0.017453292F; // pitch to radians
        float g = -rotation.getYaw() * 0.017453292F;  // yaw to radians
        float h = MathHelper.cos(g);
        float i = MathHelper.sin(g);
        float j = MathHelper.cos(f);
        float k = MathHelper.sin(f);
        return new Vec3d((double) (i * j), (double) (-k), (double) (h * j));
    }

    public float[] getRenderRotations() {
        float from = MathUtils.wrapAngle(prevRenderYaw);
        float to = MathUtils.wrapAngle(rotation == null ? mc.player.getYaw() : getServerYaw());
        float delta = to - from;
        
        if (delta > 180) delta -= 360;
        else if (delta < -180) delta += 360;

        float yaw = MathHelper.lerp(Easing.toDelta(lastRenderTime, 1000), from, from + delta);
        float pitch = MathHelper.lerp(Easing.toDelta(lastRenderTime, 1000), prevRenderPitch, 
                rotation == null ? mc.player.getPitch() : getServerPitch());
        
        prevRenderYaw = yaw;
        prevRenderPitch = pitch;

        return new float[]{yaw, pitch};
    }

    public int getModulePriority(Module module) {
        return PRIORITIES.getOrDefault(module.getName(), 0);
    }

    /**
     * Convert movement input to velocity with rotation applied
     */
    private Vec3d movementInputToVelocity(float yaw, Vec3d movementInput, float speed) {
        double d = movementInput.lengthSquared();
        if (d < 1.0E-7) {
            return Vec3d.ZERO;
        }
        Vec3d vec3d = (d > 1.0 ? movementInput.normalize() : movementInput).multiply(speed);
        float f = MathHelper.sin(yaw * MathHelper.RADIANS_PER_DEGREE);
        float g = MathHelper.cos(yaw * MathHelper.RADIANS_PER_DEGREE);
        return new Vec3d(vec3d.x * (double) g - vec3d.z * (double) f, vec3d.y, 
                vec3d.z * (double) g + vec3d.x * (double) f);
    }

    /**
     * Get the highest priority rotation from requests
     */
    private Rotation getRotationRequest() {
        Rotation rotationRequest = null;
        int priority = 0;
        for (Rotation request : requests) {
            if (request.getPriority() > priority) {
                rotationRequest = request;
                priority = request.getPriority();
            }
        }
        return rotationRequest;
    }
}
