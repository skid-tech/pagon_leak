package me.aidan.sydney.events.impl;

import lombok.Getter;
import me.aidan.sydney.events.Event;
import net.minecraft.entity.Entity;

/**
 * Event fired when an entity is pushed by another entity
 */
@Getter
public class PushEntityEvent extends Event {
    private final Entity pushed;
    private final Entity pusher;
    
    public PushEntityEvent(Entity pushed, Entity pusher) {
        this.pushed = pushed;
        this.pusher = pusher;
    }
}
