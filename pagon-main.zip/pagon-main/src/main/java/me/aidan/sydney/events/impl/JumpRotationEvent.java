package me.aidan.sydney.events.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import me.aidan.sydney.events.Event;

@Getter @Setter @AllArgsConstructor
public class JumpRotationEvent extends Event {
    private float yaw;
}
