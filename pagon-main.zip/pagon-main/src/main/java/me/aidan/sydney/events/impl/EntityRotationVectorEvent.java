package me.aidan.sydney.events.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import me.aidan.sydney.events.Event;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

@Getter @Setter @AllArgsConstructor
public class EntityRotationVectorEvent extends Event {
    private final Entity entity;
    private final float tickDelta;
    private Vec3d rotationVector;
}
