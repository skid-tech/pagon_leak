package me.aidan.sydney.events.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import me.aidan.sydney.events.Event;
import net.minecraft.util.math.Vec2f;

@Getter @Setter @AllArgsConstructor
public class CameraRotationEvent extends Event {
    private float yaw;
    private float pitch;
    private final float tickDelta;

    public void setRotation(Vec2f rotation) {
        this.yaw = rotation.x;
        this.pitch = rotation.y;
    }
}
