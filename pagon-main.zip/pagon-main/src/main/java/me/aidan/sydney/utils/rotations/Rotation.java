package me.aidan.sydney.utils.rotations;

import lombok.Getter;
import lombok.Setter;
import me.aidan.sydney.Sydney;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.utils.IMinecraft;
import net.minecraft.util.math.MathHelper;

import java.util.Arrays;

@Getter @Setter
public class Rotation implements IMinecraft {
    private float yaw, pitch;
    private final Module module;
    private final int priority;
    private long time;
    private boolean snap;

    public Rotation(float yaw, float pitch, int priority) {
        this(yaw, pitch, priority, false);
    }

    public Rotation(float yaw, float pitch, int priority, boolean snap) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.module = null;
        this.priority = priority;
        this.snap = snap;
        this.time = System.currentTimeMillis();
    }

    // Kami-style constructor - default priority 100, no snap
    public Rotation(float yaw, float pitch) {
        this(yaw, pitch, 100, false);
    }

    public Rotation(float yaw, float pitch, Module module, int priority) {
        this(yaw, pitch, module, priority, false);
    }

    public Rotation(float yaw, float pitch, Module module, int priority, boolean snap) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.module = module;
        this.priority = priority;
        this.snap = snap;
        this.time = System.currentTimeMillis();
    }

    /**
     * Apply GCD sensitivity correction to rotation for Grim compatibility
     * This is the core method from Kami that fixes rotation precision
     */
    public Rotation correctSensitivity(Rotation prevRotation) {
        Rotation deltaRotation = closestDelta(prevRotation);
        Pair<Double, Double>[] cursorDeltas = approximateCursorDeltas(deltaRotation);
        Rotation[] newRotations = Arrays.stream(cursorDeltas)
                .map(cursorDelta -> calculateNewRotation(prevRotation, cursorDelta))
                .toArray(Rotation[]::new);

        return Arrays.stream(newRotations)
                .min((r1, r2) -> Float.compare(fov(r1), fov(r2)))
                .orElse(newRotations[0]);
    }

    /**
     * Calculate new rotation from cursor delta
     */
    public Rotation calculateNewRotation(Rotation prevRotation, Pair<Double, Double> cursorDeltas) {
        double gcd = getGcd();
        Rotation rotationChange = new Rotation((float) (cursorDeltas.getKey() * gcd) * 0.15F, 
                                               (float) (cursorDeltas.getValue() * gcd) * 0.15F, 
                                               this.priority);
        Rotation newRotation = new Rotation(prevRotation.yaw + rotationChange.yaw, 
                                            prevRotation.pitch + rotationChange.pitch, 
                                            this.priority);
        newRotation = new Rotation(newRotation.yaw, 
                                   Math.max(-90F, Math.min(90F, newRotation.pitch)),
                                   this.priority);
        return newRotation;
    }

    /**
     * Calculate distance between two rotations
     */
    private float dist(Rotation deltaRotation) {
        return (float) Math.sqrt(deltaRotation.yaw * deltaRotation.yaw + 
                                deltaRotation.pitch * deltaRotation.pitch);
    }

    /**
     * Calculate field of view (angular distance) to another rotation
     */
    public float fov(Rotation other) {
        return dist(closestDelta(other));
    }

    /**
     * Get GCD value based on mouse sensitivity
     * Critical for Grim compatibility
     */
    private static double getGcd() {
        if (mc.options == null || mc.player == null) return 1.0;
        
        double sensitivity = mc.options.getMouseSensitivity().getValue() * 0.6F + 0.2F;
        double sensitivityPow3 = sensitivity * sensitivity * sensitivity;
        double sensitivityPow3Mult8 = sensitivityPow3 * 8.0;

        return (mc.options.getPerspective().isFirstPerson() && mc.player.isUsingSpyglass())
                ? sensitivityPow3
                : sensitivityPow3Mult8;
    }

    /**
     * Approximate cursor deltas for smooth rotation
     * Returns 4 possible cursor movements (floor/ceil combinations)
     */
    public static Pair<Double, Double>[] approximateCursorDeltas(Rotation deltaRotation) {
        double gcd = getGcd() * 0.15F;
        double targetX = -deltaRotation.yaw / gcd;
        double targetY = -deltaRotation.pitch / gcd;
        return new Pair[]{
                new Pair<>(Math.floor(targetX), Math.floor(targetY)),
                new Pair<>(Math.ceil(targetX), Math.floor(targetY)),
                new Pair<>(Math.ceil(targetX), Math.ceil(targetY)),
                new Pair<>(Math.floor(targetX), Math.ceil(targetY))
        };
    }

    /**
     * Calculate the closest delta (difference) between two rotations
     * Properly handles angle wrapping
     */
    public Rotation closestDelta(Rotation other) {
        return new Rotation(MathHelper.wrapDegrees(other.yaw - yaw), 
                           other.pitch - pitch, 
                           this.priority);
    }

    /**
     * Apply sensitivity correction fix - main entry point
     * Uses current rotation manager state
     */
    public Rotation fix() {
        Rotation rotation = Sydney.ROTATION_MANAGER.getRotation();
        if (rotation == null) {
            rotation = new Rotation(Sydney.ROTATION_MANAGER.getRotationYaw(), 
                                   Sydney.ROTATION_MANAGER.getRotationPitch(),
                                   this.priority);
        }
        return correctSensitivity(rotation);
    }

    /**
     * Simple pair class for cursor delta calculations
     */
    public static class Pair<K, V> {
        private final K key;
        private final V value;

        public Pair(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }

        // Kami-style short method names
        public K key() {
            return key;
        }

        public V value() {
            return value;
        }
    }
}