package me.aidan.sydney.events.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import me.aidan.sydney.events.Event;
import net.minecraft.util.Hand;

@Getter @Setter @AllArgsConstructor
public class InteractItemEvent extends Event {
    private Hand hand;
}
