package me.aidan.sydney.modules.impl.core;

import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;
import me.aidan.sydney.settings.impl.BooleanSetting;
import me.aidan.sydney.settings.impl.NumberSetting;

@RegisterModule(name = "Rotations", description = "Manages the client's rotation system.", category = Module.Category.CORE, persistent = true, drawn = false)
public class RotationsModule extends Module {
    public BooleanSetting movementFix = new BooleanSetting("MovementFix", "Fixes movement direction when rotating. Required for Grim compatibility.", true);
    public BooleanSetting mouseSensFix = new BooleanSetting("MouseSensFix", "Applies GCD fix for mouse sensitivity. Prevents Grim rotation flags.", true);
    public BooleanSetting webJumpFix = new BooleanSetting("WebJumpFix", "Disables sprint during web jumps to prevent Grim flags.", true);
    public NumberSetting preserveTicks = new NumberSetting("PreserveTicks", "Ticks to preserve rotations after reaching target. Higher = smoother but slower reset.", 10.0, 0.0, 20.0);
}
