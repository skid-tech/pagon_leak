package me.aidan.sydney.modules.impl.core;

import me.aidan.sydney.Sydney;
import me.aidan.sydney.events.SubscribeEvent;
import me.aidan.sydney.events.impl.*;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;
import me.aidan.sydney.modules.impl.combat.AutoCrystalModule;
import me.aidan.sydney.settings.impl.BooleanSetting;
import me.aidan.sydney.settings.impl.NumberSetting;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitiesDestroyS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@RegisterModule(name = "AutoCrystalDebug", description = "Detects and logs AutoCrystal freeze/stall causes on Grim anticheat.", category = Module.Category.CORE)
public class AutoCrystalDebugModule extends Module {
    
    // Settings
    public BooleanSetting autoLog = new BooleanSetting("AutoLog", "Automatically log to file when stall is detected.", true);
    public BooleanSetting logPlacement = new BooleanSetting("LogPlacement", "Log all crystal placement attempts.", true);
    public BooleanSetting logAttack = new BooleanSetting("LogAttack", "Log all crystal attack attempts.", true);
    public BooleanSetting logSpawn = new BooleanSetting("LogSpawn", "Log all crystal spawn packets.", true);
    public BooleanSetting logRotation = new BooleanSetting("LogRotation", "Log rotation changes during crystal interactions.", true);
    public NumberSetting stallThreshold = new NumberSetting("StallThreshold", "Time without action to consider as stall (ticks).", 20.0, 5.0, 100.0);
    public BooleanSetting chatNotify = new BooleanSetting("ChatNotify", "Send chat notification when stall is detected.", true);
    public BooleanSetting trackTimings = new BooleanSetting("TrackTimings", "Track detailed timing between actions.", true);
    
    // Data tracking
    private final List<CrystalDebugData> debugHistory = new ArrayList<>();
    private final Map<BlockPos, Long> placementAttempts = new ConcurrentHashMap<>();
    private final Map<Integer, Long> attackAttempts = new ConcurrentHashMap<>();
    private final Map<BlockPos, CrystalPlacementData> recentPlacements = new ConcurrentHashMap<>();
    private final Map<Integer, CrystalSpawnData> recentSpawns = new ConcurrentHashMap<>();
    
    private final DecimalFormat df = new DecimalFormat("0.000");
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private final SimpleDateFormat fileFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
    
    // State tracking
    private long lastPlaceAttempt = 0;
    private long lastAttackAttempt = 0;
    private long lastCrystalSpawn = 0;
    private long lastCrystalDestroy = 0;
    private int tickCounter = 0;
    private int stallCount = 0;
    private int totalPlacements = 0;
    private int totalAttacks = 0;
    private int failedPlacements = 0;
    private int missedAttacks = 0;
    
    // Rotation tracking
    private float lastYaw = 0;
    private float lastPitch = 0;
    private boolean rotationChanged = false;
    
    // Crystal timing tracking
    private long placeToSpawnTime = 0;
    private long spawnToAttackTime = 0;
    
    // Current state
    private String currentState = "Idle";
    private String lastFailReason = "None";
    
    @Override
    public void onEnable() {
        super.onEnable();
        debugHistory.clear();
        placementAttempts.clear();
        attackAttempts.clear();
        recentPlacements.clear();
        recentSpawns.clear();
        stallCount = 0;
        totalPlacements = 0;
        totalAttacks = 0;
        failedPlacements = 0;
        missedAttacks = 0;
        tickCounter = 0;
        currentState = "Idle";
        Sydney.CHAT_MANAGER.message("§a[AutoCrystalDebug] §7Enabled. Monitoring AutoCrystal for stalls and issues...");
    }
    
    @Override
    public void onDisable() {
        super.onDisable();
        if (autoLog.getValue() && !debugHistory.isEmpty()) {
            saveToFile();
        }
        
        String summary = String.format(
            "§a[AutoCrystalDebug] §7Stats: §ePlacements: §f%d §7(§c%d failed§7) | §eAttacks: §f%d §7(§c%d missed§7) | §eStalls: §c%d",
            totalPlacements, failedPlacements, totalAttacks, missedAttacks, stallCount
        );
        Sydney.CHAT_MANAGER.message(summary);
    }
    
    @SubscribeEvent
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) return;
        
        tickCounter++;
        
        // Clean old data
        long currentTime = System.currentTimeMillis();
        placementAttempts.entrySet().removeIf(entry -> currentTime - entry.getValue() > 5000);
        attackAttempts.entrySet().removeIf(entry -> currentTime - entry.getValue() > 5000);
        recentPlacements.entrySet().removeIf(entry -> currentTime - entry.getValue().timestamp > 10000);
        recentSpawns.entrySet().removeIf(entry -> currentTime - entry.getValue().timestamp > 10000);
        
        // Detect stalls
        detectStalls();
        
        // Track rotation changes
        if (logRotation.getValue()) {
            trackRotations();
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(PacketSendEvent event) {
        if (mc.player == null || mc.world == null) return;
        
        long currentTime = System.currentTimeMillis();
        
        // Track crystal placement packets
        if (event.getPacket() instanceof PlayerInteractBlockC2SPacket packet) {
            if (mc.player.getMainHandStack().getItem() == Items.END_CRYSTAL || 
                mc.player.getOffHandStack().getItem() == Items.END_CRYSTAL) {
                
                BlockPos pos = packet.getBlockHitResult().getBlockPos();
                handlePlacementAttempt(pos, currentTime);
            }
        }
        
        // Track crystal attack packets
        if (event.getPacket() instanceof PlayerInteractEntityC2SPacket) {
            try {
                // Extract entity ID via reflection
                java.lang.reflect.Field field = event.getPacket().getClass().getDeclaredField("entityId");
                field.setAccessible(true);
                int entityId = field.getInt(event.getPacket());
                
                handleAttackAttempt(entityId, currentTime);
            } catch (Exception ignored) {}
        }
    }
    
    @SubscribeEvent
    public void onPacketReceive(PacketReceiveEvent event) {
        if (mc.player == null || mc.world == null) return;
        
        long currentTime = System.currentTimeMillis();
        
        // Track crystal spawn packets
        if (event.getPacket() instanceof EntitySpawnS2CPacket packet) {
            if (logSpawn.getValue()) {
                BlockPos pos = BlockPos.ofFloored(packet.getX(), packet.getY(), packet.getZ()).down();
                handleCrystalSpawn(packet.getEntityId(), pos, currentTime);
            }
        }
        
        // Track crystal destroy packets
        if (event.getPacket() instanceof EntitiesDestroyS2CPacket packet) {
            for (int id : packet.getEntityIds()) {
                handleCrystalDestroy(id, currentTime);
            }
        }
    }
    
    @SubscribeEvent
    public void onServerRotation(ServerRotationEvent event) {
        if (!logRotation.getValue()) return;
        if (Float.isNaN(event.getYaw()) || Float.isNaN(event.getPitch())) return;
        
        float yawDiff = Math.abs(event.getYaw() - lastYaw);
        float pitchDiff = Math.abs(event.getPitch() - lastPitch);
        
        if (yawDiff > 1.0f || pitchDiff > 1.0f) {
            rotationChanged = true;
        }
        
        lastYaw = event.getYaw();
        lastPitch = event.getPitch();
    }
    
    private void handlePlacementAttempt(BlockPos pos, long currentTime) {
        totalPlacements++;
        lastPlaceAttempt = currentTime;
        currentState = "Placing";
        
        placementAttempts.put(pos, currentTime);
        
        CrystalPlacementData data = new CrystalPlacementData(
            currentTime,
            pos,
            mc.player.getPos(),
            Sydney.ROTATION_MANAGER.getRotationYaw(),
            Sydney.ROTATION_MANAGER.getRotationPitch(),
            getActiveModules(),
            rotationChanged,
            tickCounter
        );
        
        recentPlacements.put(pos, data);
        rotationChanged = false;
        
        if (logPlacement.getValue()) {
            logDebugEvent("PLACEMENT_ATTEMPT", pos, data);
        }
    }
    
    private void handleAttackAttempt(int entityId, long currentTime) {
        totalAttacks++;
        lastAttackAttempt = currentTime;
        currentState = "Attacking";
        
        attackAttempts.put(entityId, currentTime);
        
        // Check if this crystal exists
        EndCrystalEntity crystal = null;
        for (EndCrystalEntity entity : mc.world.getEntitiesByClass(EndCrystalEntity.class, 
                mc.player.getBoundingBox().expand(10), e -> e.getId() == entityId)) {
            crystal = entity;
            break;
        }
        
        if (crystal == null) {
            missedAttacks++;
            logDebugEvent("ATTACK_FAILED", null, "Crystal entity not found: ID=" + entityId);
        } else {
            BlockPos pos = crystal.getBlockPos().down();
            
            // Calculate spawn to attack time
            if (recentSpawns.containsKey(entityId)) {
                spawnToAttackTime = currentTime - recentSpawns.get(entityId).timestamp;
            }
            
            if (logAttack.getValue()) {
                CrystalAttackData data = new CrystalAttackData(
                    currentTime,
                    entityId,
                    pos,
                    crystal.getPos(),
                    mc.player.getPos(),
                    spawnToAttackTime,
                    tickCounter
                );
                logDebugEvent("ATTACK_ATTEMPT", pos, data);
            }
        }
    }
    
    private void handleCrystalSpawn(int entityId, BlockPos pos, long currentTime) {
        lastCrystalSpawn = currentTime;
        
        // Check if we placed this crystal
        if (placementAttempts.containsKey(pos)) {
            placeToSpawnTime = currentTime - placementAttempts.get(pos);
            
            if (placeToSpawnTime > Sydney.SERVER_MANAGER.getPing() * 3) {
                // Slow spawn - potential issue
                logDebugEvent("SLOW_SPAWN", pos, 
                    String.format("Took %dms to spawn (ping: %dms)", placeToSpawnTime, Sydney.SERVER_MANAGER.getPing()));
            }
        } else {
            // Crystal not placed by us
            failedPlacements++;
        }
        
        CrystalSpawnData spawnData = new CrystalSpawnData(
            currentTime,
            entityId,
            pos,
            placeToSpawnTime,
            tickCounter
        );
        
        recentSpawns.put(entityId, spawnData);
    }
    
    private void handleCrystalDestroy(int entityId, long currentTime) {
        lastCrystalDestroy = currentTime;
        
        if (attackAttempts.containsKey(entityId)) {
            long attackToDestroyTime = currentTime - attackAttempts.get(entityId);
            
            if (attackToDestroyTime > Sydney.SERVER_MANAGER.getPing() * 3) {
                logDebugEvent("SLOW_DESTROY", null,
                    String.format("Crystal %d took %dms to destroy", entityId, attackToDestroyTime));
            }
        }
    }
    
    private void detectStalls() {
        if (mc.player == null || mc.world == null) return;
        
        AutoCrystalModule autoCrystal = Sydney.MODULE_MANAGER.getModule(AutoCrystalModule.class);
        if (autoCrystal == null || !autoCrystal.isToggled()) {
            currentState = "Idle (AC Disabled)";
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        long timeSincePlace = currentTime - lastPlaceAttempt;
        long timeSinceAttack = currentTime - lastAttackAttempt;
        long timeSinceSpawn = currentTime - lastCrystalSpawn;
        
        long stallThresholdMs = (long) (stallThreshold.getValue().doubleValue() * 50); // ticks to ms
        
        // Detect if AutoCrystal is active but not doing anything
        if (autoCrystal.getTarget() != null) {
            // Has target but not placing/attacking
            if (timeSincePlace > stallThresholdMs && timeSinceAttack > stallThresholdMs) {
                handleStall(currentTime, timeSincePlace, timeSinceAttack);
            }
        }
        
        // Check for placement failures
        for (Map.Entry<BlockPos, Long> entry : placementAttempts.entrySet()) {
            long timeSincePlacement = currentTime - entry.getValue();
            
            // If placement was attempted but no spawn after threshold
            if (timeSincePlacement > stallThresholdMs && !recentSpawns.values().stream()
                    .anyMatch(spawn -> spawn.position.equals(entry.getKey()))) {
                
                handleFailedPlacement(entry.getKey(), timeSincePlacement);
                placementAttempts.remove(entry.getKey());
            }
        }
    }
    
    private void handleStall(long currentTime, long timeSincePlace, long timeSinceAttack) {
        stallCount++;
        currentState = "STALLED";
        lastFailReason = analyzeStallReason();
        
        if (chatNotify.getValue()) {
            Sydney.CHAT_MANAGER.message(String.format(
                "§c[AutoCrystal STALL] §7No action for §e%dms §7| Reason: §e%s",
                Math.min(timeSincePlace, timeSinceAttack),
                lastFailReason
            ));
        }
        
        CrystalDebugData debugData = new CrystalDebugData(
            currentTime,
            "STALL",
            null,
            timeSincePlace,
            timeSinceAttack,
            lastFailReason,
            getActiveModules(),
            Sydney.ROTATION_MANAGER.getRotationYaw(),
            Sydney.ROTATION_MANAGER.getRotationPitch(),
            tickCounter
        );
        
        debugHistory.add(debugData);
        
        if (autoLog.getValue()) {
            saveStallToFile(debugData);
        }
    }
    
    private void handleFailedPlacement(BlockPos pos, long timeSincePlacement) {
        failedPlacements++;
        lastFailReason = "Placement packet sent but crystal never spawned";
        
        if (chatNotify.getValue()) {
            Sydney.CHAT_MANAGER.message(String.format(
                "§c[Failed Placement] §7Position: §e%s §7| Time: §e%dms",
                pos.toShortString(),
                timeSincePlacement
            ));
        }
        
        logDebugEvent("PLACEMENT_FAILED", pos, 
            String.format("No spawn after %dms (ping: %dms)", timeSincePlacement, Sydney.SERVER_MANAGER.getPing()));
    }
    
    private String analyzeStallReason() {
        AutoCrystalModule autoCrystal = Sydney.MODULE_MANAGER.getModule(AutoCrystalModule.class);
        if (autoCrystal == null) return "AutoCrystal module not found";
        
        StringBuilder reason = new StringBuilder();
        
        // Check for common issues
        if (!autoCrystal.attack.getValue() && !autoCrystal.place.getValue()) {
            reason.append("Both attack and place disabled | ");
        }
        
        if (autoCrystal.yawStep.getValue()) {
            reason.append("YawStep active (slow rotations) | ");
        }
        
        if (autoCrystal.raytrace.getValue()) {
            reason.append("Raytrace enabled (may block actions) | ");
        }
        
        if (mc.player.isUsingItem()) {
            String itemMode = autoCrystal.whileEating.getValue();
            if (itemMode.equals("None")) {
                reason.append("Using item (whileEating=None) | ");
            }
        }
        
        if (!autoCrystal.rotate.getValue().equals("None")) {
            float rotationDiff = Math.abs(Sydney.ROTATION_MANAGER.getRotationYaw() - mc.player.getYaw());
            if (rotationDiff > 90) {
                reason.append("Large rotation difference (" + df.format(rotationDiff) + "°) | ");
            }
        }
        
        // Check inventory
        boolean hasCrystals = mc.player.getInventory().containsAny(stack -> stack.getItem() == Items.END_CRYSTAL);
        if (!hasCrystals && autoCrystal.autoSwitch.getValue().equals("None")) {
            reason.append("No crystals in inventory | ");
        }
        
        // Check ping
        long ping = Sydney.SERVER_MANAGER.getPing();
        if (ping > 200) {
            reason.append("High ping (" + ping + "ms) | ");
        }
        
        // Check sequential mode
        if (autoCrystal.sequential.getValue().equals("Strict")) {
            reason.append("Sequential=Strict (waits for spawn) | ");
        }
        
        if (reason.length() == 0) {
            return "Unknown - possible Grim blocking actions";
        }
        
        return reason.substring(0, reason.length() - 3); // Remove last " | "
    }
    
    private void trackRotations() {
        float currentYaw = Sydney.ROTATION_MANAGER.getRotationYaw();
        float currentPitch = Sydney.ROTATION_MANAGER.getRotationPitch();
        
        float yawDiff = Math.abs(currentYaw - lastYaw);
        float pitchDiff = Math.abs(currentPitch - lastPitch);
        
        if (yawDiff > 45 || pitchDiff > 45) {
            // Large rotation change
            logDebugEvent("LARGE_ROTATION", null, 
                String.format("Yaw Δ: %.2f° | Pitch Δ: %.2f°", yawDiff, pitchDiff));
        }
    }
    
    private void logDebugEvent(String eventType, BlockPos pos, Object data) {
        // Log to console for real-time debugging
        if (Sydney.MODULE_MANAGER.getModule(AutoCrystalModule.class) != null) {
            // Can add console output here if needed
        }
    }
    
    private List<String> getActiveModules() {
        List<String> activeModules = new ArrayList<>();
        for (Module module : Sydney.MODULE_MANAGER.getModules()) {
            if (module.isToggled() && module != this) {
                activeModules.add(module.getName());
            }
        }
        return activeModules;
    }
    
    private void saveStallToFile(CrystalDebugData data) {
        File dir = new File(mc.runDirectory, "sydney/autocrystal_debug");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        
        File file = new File(dir, "stall_" + fileFormat.format(new Date()) + ".txt");
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(formatDebugData(data));
            writer.newLine();
        } catch (IOException e) {
            Sydney.CHAT_MANAGER.error("§c[AutoCrystalDebug] §7Failed to save log: " + e.getMessage());
        }
    }
    
    private void saveToFile() {
        if (debugHistory.isEmpty()) return;
        
        File dir = new File(mc.runDirectory, "sydney/autocrystal_debug");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        
        File file = new File(dir, "debug_session_" + fileFormat.format(new Date()) + ".txt");
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write("=".repeat(80));
            writer.newLine();
            writer.write("Sydney Client - AutoCrystal Debug Report");
            writer.newLine();
            writer.write("Session Date: " + dateFormat.format(new Date()));
            writer.newLine();
            writer.write("=".repeat(80));
            writer.newLine();
            writer.newLine();
            
            writer.write("SESSION STATISTICS:");
            writer.newLine();
            writer.write("-".repeat(80));
            writer.newLine();
            writer.write("Total Placements: " + totalPlacements);
            writer.newLine();
            writer.write("Failed Placements: " + failedPlacements + " (" + 
                String.format("%.1f%%", totalPlacements > 0 ? (failedPlacements * 100.0 / totalPlacements) : 0) + ")");
            writer.newLine();
            writer.write("Total Attacks: " + totalAttacks);
            writer.newLine();
            writer.write("Missed Attacks: " + missedAttacks + " (" + 
                String.format("%.1f%%", totalAttacks > 0 ? (missedAttacks * 100.0 / totalAttacks) : 0) + ")");
            writer.newLine();
            writer.write("Total Stalls: " + stallCount);
            writer.newLine();
            writer.newLine();
            
            writer.write("STALL EVENTS:");
            writer.newLine();
            writer.write("-".repeat(80));
            writer.newLine();
            
            for (int i = 0; i < debugHistory.size(); i++) {
                writer.write("STALL #" + (i + 1));
                writer.newLine();
                writer.write(formatDebugData(debugHistory.get(i)));
                writer.newLine();
                writer.newLine();
            }
            
            Sydney.CHAT_MANAGER.message("§a[AutoCrystalDebug] §7Saved to: §e" + file.getName());
        } catch (IOException e) {
            Sydney.CHAT_MANAGER.error("§c[AutoCrystalDebug] §7Failed to save: " + e.getMessage());
        }
    }
    
    private String formatDebugData(CrystalDebugData data) {
        StringBuilder sb = new StringBuilder();
        
        sb.append("Time: ").append(dateFormat.format(new Date(data.timestamp))).append("\n");
        sb.append("Tick: ").append(data.tickCount).append("\n");
        sb.append("Event Type: ").append(data.eventType).append("\n");
        sb.append("\n");
        
        sb.append("TIMING DATA:\n");
        sb.append("  Time Since Last Place: ").append(data.timeSincePlace).append("ms\n");
        sb.append("  Time Since Last Attack: ").append(data.timeSinceAttack).append("ms\n");
        sb.append("\n");
        
        sb.append("ROTATION DATA:\n");
        sb.append("  Yaw: ").append(df.format(data.yaw)).append("°\n");
        sb.append("  Pitch: ").append(df.format(data.pitch)).append("°\n");
        sb.append("\n");
        
        sb.append("REASON: ").append(data.reason).append("\n");
        sb.append("\n");
        
        sb.append("ACTIVE MODULES (").append(data.activeModules.size()).append("):\n");
        if (data.activeModules.isEmpty()) {
            sb.append("  (none)\n");
        } else {
            for (String module : data.activeModules) {
                sb.append("  - ").append(module).append("\n");
            }
        }
        
        return sb.toString();
    }
    
    public String getDisplayInfo() {
        return String.format("§7[§eState: §f%s§7] [§eStalls: §c%d§7]", currentState, stallCount);
    }
    
    // Data container classes
    private static class CrystalDebugData {
        final long timestamp;
        final String eventType;
        final BlockPos position;
        final long timeSincePlace;
        final long timeSinceAttack;
        final String reason;
        final List<String> activeModules;
        final float yaw;
        final float pitch;
        final int tickCount;
        
        CrystalDebugData(long timestamp, String eventType, BlockPos position,
                        long timeSincePlace, long timeSinceAttack, String reason,
                        List<String> activeModules, float yaw, float pitch, int tickCount) {
            this.timestamp = timestamp;
            this.eventType = eventType;
            this.position = position;
            this.timeSincePlace = timeSincePlace;
            this.timeSinceAttack = timeSinceAttack;
            this.reason = reason;
            this.activeModules = new ArrayList<>(activeModules);
            this.yaw = yaw;
            this.pitch = pitch;
            this.tickCount = tickCount;
        }
    }
    
    private static class CrystalPlacementData {
        final long timestamp;
        final BlockPos position;
        final Vec3d playerPos;
        final float yaw;
        final float pitch;
        final List<String> activeModules;
        final boolean rotationChanged;
        final int tickCount;
        
        CrystalPlacementData(long timestamp, BlockPos position, Vec3d playerPos,
                            float yaw, float pitch, List<String> activeModules,
                            boolean rotationChanged, int tickCount) {
            this.timestamp = timestamp;
            this.position = position;
            this.playerPos = playerPos;
            this.yaw = yaw;
            this.pitch = pitch;
            this.activeModules = new ArrayList<>(activeModules);
            this.rotationChanged = rotationChanged;
            this.tickCount = tickCount;
        }
    }
    
    private static class CrystalSpawnData {
        final long timestamp;
        final int entityId;
        final BlockPos position;
        final long placeToSpawnTime;
        final int tickCount;
        
        CrystalSpawnData(long timestamp, int entityId, BlockPos position,
                        long placeToSpawnTime, int tickCount) {
            this.timestamp = timestamp;
            this.entityId = entityId;
            this.position = position;
            this.placeToSpawnTime = placeToSpawnTime;
            this.tickCount = tickCount;
        }
    }
    
    private static class CrystalAttackData {
        final long timestamp;
        final int entityId;
        final BlockPos position;
        final Vec3d crystalPos;
        final Vec3d playerPos;
        final long spawnToAttackTime;
        final int tickCount;
        
        CrystalAttackData(long timestamp, int entityId, BlockPos position,
                         Vec3d crystalPos, Vec3d playerPos,
                         long spawnToAttackTime, int tickCount) {
            this.timestamp = timestamp;
            this.entityId = entityId;
            this.position = position;
            this.crystalPos = crystalPos;
            this.playerPos = playerPos;
            this.spawnToAttackTime = spawnToAttackTime;
            this.tickCount = tickCount;
        }
    }
}
