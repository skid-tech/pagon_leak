package me.aidan.sydney.events.impl;

import me.aidan.sydney.events.Event;

/**
 * Event fired when player is pushed out of blocks
 */
public class PushOutOfBlocksEvent extends Event {
    
}
