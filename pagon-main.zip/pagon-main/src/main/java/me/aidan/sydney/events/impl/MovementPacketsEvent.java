package me.aidan.sydney.events.impl;

import lombok.Getter;
import lombok.Setter;
import me.aidan.sydney.events.Event;

@Getter @Setter
public class MovementPacketsEvent extends Event {
    private float yaw;
    private float pitch;
}
