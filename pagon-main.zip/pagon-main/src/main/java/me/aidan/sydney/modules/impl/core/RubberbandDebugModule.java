package me.aidan.sydney.modules.impl.core;

import me.aidan.sydney.Sydney;
import me.aidan.sydney.events.SubscribeEvent;
import me.aidan.sydney.events.impl.PacketReceiveEvent;
import me.aidan.sydney.events.impl.PacketSendEvent;
import me.aidan.sydney.events.impl.PlayerUpdateEvent;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;
import me.aidan.sydney.settings.impl.BooleanSetting;
import me.aidan.sydney.settings.impl.NumberSetting;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.math.Vec3d;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RegisterModule(name = "RubberbandDebug", description = "Detects and logs rubberband causes to help debug anticheat issues.", category = Module.Category.CORE)
public class RubberbandDebugModule extends Module {
    
    // Settings
    public BooleanSetting autoLog = new BooleanSetting("AutoLog", "Automatically log to file when rubberband is detected.", true);
    public BooleanSetting logVelocity = new BooleanSetting("LogVelocity", "Log velocity packets that could cause rubberbands.", true);
    public BooleanSetting logMovement = new BooleanSetting("LogMovement", "Log all movement packets (creates large files).", false);
    public NumberSetting minDistance = new NumberSetting("MinDistance", "Minimum distance to consider as rubberband (blocks).", 0.1, 0.01, 10.0);
    public BooleanSetting chatNotify = new BooleanSetting("ChatNotify", "Send chat notification when rubberband is detected.", true);
    
    // Data tracking
    private final List<RubberbandData> rubberbandHistory = new ArrayList<>();
    private final DecimalFormat df = new DecimalFormat("0.000");
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private final SimpleDateFormat fileFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
    
    // Position tracking
    private Vec3d lastSentPosition = null;
    private Vec3d lastClientPosition = null;
    private long lastMovementTime = 0;
    private int tickCounter = 0;
    private int rubberbandCount = 0;
    
    // Velocity tracking
    private Vec3d lastVelocity = Vec3d.ZERO;
    private long lastVelocityTime = 0;
    
    @Override
    public void onEnable() {
        super.onEnable();
        rubberbandHistory.clear();
        rubberbandCount = 0;
        lastSentPosition = null;
        lastClientPosition = null;
        if (mc.player != null) {
            lastClientPosition = mc.player.getPos();
        }
        Sydney.CHAT_MANAGER.message("§a[RubberbandDebug] §7Enabled. Monitoring for rubberbands...");
    }
    
    @Override
    public void onDisable() {
        super.onDisable();
        if (autoLog.getValue() && !rubberbandHistory.isEmpty()) {
            saveToFile(false);
        }
        Sydney.CHAT_MANAGER.message("§a[RubberbandDebug] §7Disabled. Detected §c" + rubberbandCount + " §7rubberbands.");
    }
    
    @SubscribeEvent
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) return;
        
        tickCounter++;
        lastClientPosition = mc.player.getPos();
    }
    
    @SubscribeEvent
    public void onPacketSend(PacketSendEvent event) {
        if (mc.player == null || mc.world == null) return;
        
        if (event.getPacket() instanceof PlayerMoveC2SPacket packet) {
            if (packet.changesPosition()) {
                double x = packet.getX(mc.player.getX());
                double y = packet.getY(mc.player.getY());
                double z = packet.getZ(mc.player.getZ());
                lastSentPosition = new Vec3d(x, y, z);
                lastMovementTime = System.currentTimeMillis();
                
                if (logMovement.getValue()) {
                    logMovementPacket(packet, true);
                }
            }
        }
    }
    
    @SubscribeEvent
    public void onPacketReceive(PacketReceiveEvent event) {
        if (mc.player == null || mc.world == null) return;
        
        // Detect rubberband (server position correction)
        if (event.getPacket() instanceof PlayerPositionLookS2CPacket packet) {
            handleRubberband(packet);
        }
        
        // Track velocity changes
        if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket packet) {
            if (logVelocity.getValue() && packet.getEntityId() == mc.player.getId()) {
                handleVelocity(packet);
            }
        }
    }
    
    private void handleRubberband(PlayerPositionLookS2CPacket packet) {
        if (lastSentPosition == null || lastClientPosition == null) return;
        
        Vec3d serverPos = new Vec3d(
            packet.change().position().getX(), 
            packet.change().position().getY(), 
            packet.change().position().getZ()
        );
        double distance = lastSentPosition.distanceTo(serverPos);
        
        // Only log if distance is significant
        if (distance >= minDistance.getValue().doubleValue()) {
            rubberbandCount++;
            
            RubberbandData data = new RubberbandData(
                System.currentTimeMillis(),
                lastClientPosition,
                lastSentPosition,
                serverPos,
                distance,
                packet.change().yaw(),
                packet.change().pitch(),
                getActiveModules(),
                lastVelocity,
                System.currentTimeMillis() - lastMovementTime,
                System.currentTimeMillis() - lastVelocityTime,
                tickCounter
            );
            
            rubberbandHistory.add(data);
            
            if (chatNotify.getValue()) {
                Sydney.CHAT_MANAGER.message("§c[Rubberband] §7Distance: §e" + df.format(distance) + " §7blocks | Active modules: §e" + data.activeModules.size());
            }
            
            if (autoLog.getValue()) {
                saveRubberbandToFile(data);
            }
        }
    }
    
    private void handleVelocity(EntityVelocityUpdateS2CPacket packet) {
        double vx = packet.getVelocityX() / 8000.0;
        double vy = packet.getVelocityY() / 8000.0;
        double vz = packet.getVelocityZ() / 8000.0;
        lastVelocity = new Vec3d(vx, vy, vz);
        lastVelocityTime = System.currentTimeMillis();
    }
    
    private void logMovementPacket(PlayerMoveC2SPacket packet, boolean sent) {
        // For detailed movement logging (optional)
        // Can be expanded if needed
    }
    
    private List<String> getActiveModules() {
        List<String> activeModules = new ArrayList<>();
        for (Module module : Sydney.MODULE_MANAGER.getModules()) {
            if (module.isToggled() && module != this) {
                activeModules.add(module.getName());
            }
        }
        return activeModules;
    }
    
    private void saveRubberbandToFile(RubberbandData data) {
        File dir = new File(mc.runDirectory, "sydney/rubberbands");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        
        File file = new File(dir, "rubberband_" + fileFormat.format(new Date()) + ".txt");
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(formatRubberbandData(data));
            writer.newLine();
        } catch (IOException e) {
            Sydney.CHAT_MANAGER.error("§c[RubberbandDebug] §7Failed to save log: " + e.getMessage());
        }
    }
    
    private void saveToFile(boolean notify) {
        if (rubberbandHistory.isEmpty()) {
            if (notify) {
                Sydney.CHAT_MANAGER.error("§c[RubberbandDebug] §7No rubberbands to save!");
            }
            return;
        }
        
        File dir = new File(mc.runDirectory, "sydney/rubberbands");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        
        File file = new File(dir, "rubberband_session_" + fileFormat.format(new Date()) + ".txt");
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write("=".repeat(80));
            writer.newLine();
            writer.write("Sydney Client - Rubberband Debug Report");
            writer.newLine();
            writer.write("Session Date: " + dateFormat.format(new Date()));
            writer.newLine();
            writer.write("Total Rubberbands: " + rubberbandHistory.size());
            writer.newLine();
            writer.write("=".repeat(80));
            writer.newLine();
            writer.newLine();
            
            for (int i = 0; i < rubberbandHistory.size(); i++) {
                writer.write("RUBBERBAND #" + (i + 1));
                writer.newLine();
                writer.write("-".repeat(80));
                writer.newLine();
                writer.write(formatRubberbandData(rubberbandHistory.get(i)));
                writer.newLine();
                writer.newLine();
            }
            
            writer.write("=".repeat(80));
            writer.newLine();
            writer.write("SUMMARY");
            writer.newLine();
            writer.write("-".repeat(80));
            writer.newLine();
            
            // Calculate statistics
            double avgDistance = rubberbandHistory.stream()
                    .mapToDouble(d -> d.distance)
                    .average()
                    .orElse(0.0);
            
            double maxDistance = rubberbandHistory.stream()
                    .mapToDouble(d -> d.distance)
                    .max()
                    .orElse(0.0);
            
            writer.write("Average Distance: " + df.format(avgDistance) + " blocks");
            writer.newLine();
            writer.write("Maximum Distance: " + df.format(maxDistance) + " blocks");
            writer.newLine();
            writer.newLine();
            
            // Most common active modules
            writer.write("Most Common Active Modules:");
            writer.newLine();
            rubberbandHistory.stream()
                    .flatMap(d -> d.activeModules.stream())
                    .distinct()
                    .forEach(module -> {
                        long count = rubberbandHistory.stream()
                                .filter(d -> d.activeModules.contains(module))
                                .count();
                        try {
                            writer.write("  - " + module + ": " + count + "/" + rubberbandHistory.size() + " rubberbands");
                            writer.newLine();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
            
            Sydney.CHAT_MANAGER.message("§a[RubberbandDebug] §7Saved to: §e" + file.getName());
        } catch (IOException e) {
            Sydney.CHAT_MANAGER.error("§c[RubberbandDebug] §7Failed to save: " + e.getMessage());
        }
    }
    
    private String formatRubberbandData(RubberbandData data) {
        StringBuilder sb = new StringBuilder();
        
        sb.append("Time: ").append(dateFormat.format(new Date(data.timestamp))).append("\n");
        sb.append("Tick: ").append(data.tickCount).append("\n");
        sb.append("\n");
        
        sb.append("POSITION DATA:\n");
        sb.append("  Client Position:  X=").append(df.format(data.clientPos.x))
                .append(" Y=").append(df.format(data.clientPos.y))
                .append(" Z=").append(df.format(data.clientPos.z)).append("\n");
        sb.append("  Sent Position:    X=").append(df.format(data.sentPos.x))
                .append(" Y=").append(df.format(data.sentPos.y))
                .append(" Z=").append(df.format(data.sentPos.z)).append("\n");
        sb.append("  Server Position:  X=").append(df.format(data.serverPos.x))
                .append(" Y=").append(df.format(data.serverPos.y))
                .append(" Z=").append(df.format(data.serverPos.z)).append("\n");
        sb.append("  Rubberband Distance: ").append(df.format(data.distance)).append(" blocks\n");
        sb.append("  Time Since Last Movement: ").append(data.timeSinceMovement).append("ms\n");
        sb.append("\n");
        
        sb.append("ROTATION DATA:\n");
        sb.append("  Server Yaw:   ").append(df.format(data.serverYaw)).append("°\n");
        sb.append("  Server Pitch: ").append(df.format(data.serverPitch)).append("°\n");
        sb.append("\n");
        
        sb.append("VELOCITY DATA:\n");
        sb.append("  Last Velocity: X=").append(df.format(data.lastVelocity.x))
                .append(" Y=").append(df.format(data.lastVelocity.y))
                .append(" Z=").append(df.format(data.lastVelocity.z)).append("\n");
        sb.append("  Time Since Velocity: ").append(data.timeSinceVelocity).append("ms\n");
        sb.append("\n");
        
        sb.append("ACTIVE MODULES (").append(data.activeModules.size()).append("):\n");
        if (data.activeModules.isEmpty()) {
            sb.append("  (none)\n");
        } else {
            for (String module : data.activeModules) {
                sb.append("  - ").append(module).append("\n");
            }
        }
        
        sb.append("\n");
        sb.append("POSSIBLE CAUSES:\n");
        sb.append(analyzeCauses(data));
        
        return sb.toString();
    }
    
    private String analyzeCauses(RubberbandData data) {
        StringBuilder sb = new StringBuilder();
        
        // Check for suspicious modules
        if (data.activeModules.contains("Fly") || data.activeModules.contains("ElytraFly")) {
            sb.append("  ⚠ Flight module active - may trigger anticheat\n");
        }
        
        if (data.activeModules.contains("Speed") || data.activeModules.contains("Strafe")) {
            sb.append("  ⚠ Speed/movement module active - check speed limits\n");
        }
        
        if (data.activeModules.contains("NoSlow")) {
            sb.append("  ⚠ NoSlow active - check bypass mode compatibility\n");
        }
        
        if (data.activeModules.contains("Scaffold") || data.activeModules.contains("Tower")) {
            sb.append("  ⚠ Block placement module active - check placement timing\n");
        }
        
        if (data.activeModules.contains("Disabler")) {
            sb.append("  ⚠ Disabler active - may cause issues with packet handling\n");
        }
        
        // Check velocity
        double velocityMagnitude = data.lastVelocity.length();
        if (velocityMagnitude > 1.0 && data.timeSinceVelocity < 1000) {
            sb.append("  ⚠ Recent high velocity (").append(df.format(velocityMagnitude))
                    .append(") - may indicate knockback/explosion\n");
        }
        
        // Check distance
        if (data.distance > 5.0) {
            sb.append("  ⚠ Large rubberband distance (").append(df.format(data.distance))
                    .append(" blocks) - severe desync\n");
        } else if (data.distance > 1.0) {
            sb.append("  ⚠ Moderate rubberband distance - possible movement desync\n");
        } else {
            sb.append("  ℹ Small rubberband - likely minor correction\n");
        }
        
        // Check timing
        if (data.timeSinceMovement > 1000) {
            sb.append("  ⚠ Long time since last movement (").append(data.timeSinceMovement)
                    .append("ms) - possible timeout\n");
        }
        
        if (sb.length() == 0) {
            sb.append("  ℹ No obvious causes detected - may be normal anticheat behavior\n");
        }
        
        return sb.toString();
    }
    
    // Data container class
    private static class RubberbandData {
        final long timestamp;
        final Vec3d clientPos;
        final Vec3d sentPos;
        final Vec3d serverPos;
        final double distance;
        final float serverYaw;
        final float serverPitch;
        final List<String> activeModules;
        final Vec3d lastVelocity;
        final long timeSinceMovement;
        final long timeSinceVelocity;
        final int tickCount;
        
        RubberbandData(long timestamp, Vec3d clientPos, Vec3d sentPos, Vec3d serverPos,
                       double distance, float serverYaw, float serverPitch,
                       List<String> activeModules, Vec3d lastVelocity,
                       long timeSinceMovement, long timeSinceVelocity, int tickCount) {
            this.timestamp = timestamp;
            this.clientPos = clientPos;
            this.sentPos = sentPos;
            this.serverPos = serverPos;
            this.distance = distance;
            this.serverYaw = serverYaw;
            this.serverPitch = serverPitch;
            this.activeModules = new ArrayList<>(activeModules);
            this.lastVelocity = lastVelocity;
            this.timeSinceMovement = timeSinceMovement;
            this.timeSinceVelocity = timeSinceVelocity;
            this.tickCount = tickCount;
        }
    }
}
