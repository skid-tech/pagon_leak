package me.aidan.sydney.modules.impl.movement;

import me.aidan.sydney.Sydney;
import me.aidan.sydney.events.SubscribeEvent;
import me.aidan.sydney.events.impl.PacketReceiveEvent;
import me.aidan.sydney.events.impl.PlayerUpdateEvent;
import me.aidan.sydney.events.impl.PushEntityEvent;
import me.aidan.sydney.events.impl.PushFluidsEvent;
import me.aidan.sydney.events.impl.PushOutOfBlocksEvent;
import me.aidan.sydney.mixins.accessors.EntityVelocityUpdateS2CPacketAccessor;
import me.aidan.sydney.mixins.accessors.Vec3dAccessor;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;
import me.aidan.sydney.settings.impl.BooleanSetting;
import me.aidan.sydney.settings.impl.ModeSetting;
import me.aidan.sydney.settings.impl.NumberSetting;
import me.aidan.sydney.utils.minecraft.EntityUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityStatuses;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Advanced Velocity module with multi-anticheat support
 * Based on Shoreline's velocity system with Grim AC compatibility
 */
@RegisterModule(name = "Velocity", description = "Reduces knockback velocity with advanced anticheat bypasses.", category = Module.Category.MOVEMENT)
public class VelocityModule extends Module {
    
    // Main settings
    public BooleanSetting knockback = new BooleanSetting("Knockback", "Removes player knockback velocity", true);
    public BooleanSetting explosion = new BooleanSetting("Explosion", "Removes explosion velocity", true);
    public ModeSetting mode = new ModeSetting("Mode", "Velocity reduction mode", "Normal", new String[]{"Normal", "Walls", "Grim", "GrimV3"});
    
    // Percentage settings (Normal/Walls mode)
    public NumberSetting horizontal = new NumberSetting("Horizontal", "Horizontal knockback percentage", new ModeSetting.Visibility(mode, "Normal", "Walls"), 0.0, 0.0, 100.0);
    public NumberSetting vertical = new NumberSetting("Vertical", "Vertical knockback percentage", new ModeSetting.Visibility(mode, "Normal", "Walls"), 0.0, 0.0, 100.0);
    
    // Advanced settings
    public BooleanSetting conceal = new BooleanSetting("Conceal", "Fixes velocity on servers with excessive setbacks", false);
    
    // Walls mode settings
    public BooleanSetting wallsGroundOnly = new BooleanSetting("WallsGroundOnly", "Only apply velocity in walls while on ground", new ModeSetting.Visibility(mode, "Walls"), false);
    public BooleanSetting wallsTrapped = new BooleanSetting("WallsTrapped", "Apply velocity while player head is trapped", new ModeSetting.Visibility(mode, "Walls"), false);
    
    // Push prevention
    public BooleanSetting pushEntities = new BooleanSetting("NoPush-Entities", "Prevents being pushed by entities", true);
    public BooleanSetting pushBlocks = new BooleanSetting("NoPush-Blocks", "Prevents being pushed out of blocks", true);
    public BooleanSetting pushLiquids = new BooleanSetting("NoPush-Liquids", "Prevents being pushed by liquids", true);
    public BooleanSetting pushFishhook = new BooleanSetting("NoPush-Fishhook", "Prevents being pulled by fishing rods", true);
    
    // Internal state
    private boolean cancelVelocity;
    private boolean concealVelocity;
    
    @Override
    public void onEnable() {
        super.onEnable();
        cancelVelocity = false;
        concealVelocity = false;
    }
    
    @Override
    public void onDisable() {
        super.onDisable();
        
        // Send completion packets for Grim mode
        if (cancelVelocity && mode.getValue().equalsIgnoreCase("Grim")) {
            sendGrimCompletionPackets();
            cancelVelocity = false;
        }
        
        concealVelocity = false;
    }
    
    @Override
    public String getMetaData() {
        if (mode.getValue().equalsIgnoreCase("Normal") || mode.getValue().equalsIgnoreCase("Walls")) {
            DecimalFormat df = new DecimalFormat("0.0");
            return String.format("H:%s%%, V:%s%%", 
                df.format(horizontal.getValue().doubleValue()), 
                df.format(vertical.getValue().doubleValue()));
        }
        return mode.getValue();
    }
    
    @SubscribeEvent
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) return;
        
        // Reset conceal flag each tick
        concealVelocity = false;
        
        // Send Grim completion packets
        if (cancelVelocity && mode.getValue().equalsIgnoreCase("Grim")) {
            sendGrimCompletionPackets();
            cancelVelocity = false;
        }
    }
    
    @SubscribeEvent
    public void onPacketReceive(PacketReceiveEvent event) {
        if (mc.player == null || mc.world == null) return;
        
        // Detect setbacks for conceal mode
        if (event.getPacket() instanceof PlayerPositionLookS2CPacket && conceal.getValue()) {
            concealVelocity = true;
        }
        
        // Handle velocity packets
        if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket packet && knockback.getValue()) {
            handleVelocityPacket(event, packet);
        }
        
        // Handle explosion packets
        else if (event.getPacket() instanceof ExplosionS2CPacket packet && explosion.getValue()) {
            handleExplosionPacket(event, packet);
        }
        
        // Handle bundle packets (critical for Grim AC!)
        else if (event.getPacket() instanceof BundleS2CPacket bundlePacket) {
            handleBundlePacket(event, bundlePacket);
        }
        
        // Handle fishing rod hooks
        else if (event.getPacket() instanceof EntityStatusS2CPacket packet && pushFishhook.getValue()) {
            handleFishhookPacket(event, packet);
        }
        
        // Handle entity damage (GrimV3 specific)
        else if (event.getPacket() instanceof EntityDamageS2CPacket packet && 
                 mode.getValue().equalsIgnoreCase("GrimV3") &&
                 packet.entityId() == mc.player.getId() && isPhased()) {
            // GrimV3 bypass: send ground packets to cancel velocity
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(false, mc.player.horizontalCollision));
            mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision));
        }
    }
    
    private void handleVelocityPacket(PacketReceiveEvent event, EntityVelocityUpdateS2CPacket packet) {
        // Only handle packets for the player
        if (packet.getEntityId() != mc.player.getId()) return;
        
        // Skip if concealing and packet is reset
        if (concealVelocity && packet.getVelocityX() == 0 && 
            packet.getVelocityY() == 0 && packet.getVelocityZ() == 0) {
            concealVelocity = false;
            return;
        }
        
        // Walls mode: only apply when phased
        if (mode.getValue().equalsIgnoreCase("Walls")) {
            if (!isPhased() && (!wallsTrapped.getValue() || !isWallsTrapped())) {
                return;
            }
            
            if (wallsGroundOnly.getValue() && !Sydney.POSITION_MANAGER.isServerOnGround()) {
                return;
            }
        }
        
        // Apply velocity reduction based on mode
        switch (mode.getValue()) {
            case "Normal":
            case "Walls":
                // Modify packet velocity
                if (horizontal.getValue().doubleValue() == 0.0 && vertical.getValue().doubleValue() == 0.0) {
                    event.setCancelled(true);
                    return;
                }
                
                ((EntityVelocityUpdateS2CPacketAccessor) packet).setVelocityX(
                    (int) (packet.getVelocityX() * (horizontal.getValue().doubleValue() / 100.0))
                );
                ((EntityVelocityUpdateS2CPacketAccessor) packet).setVelocityY(
                    (int) (packet.getVelocityY() * (vertical.getValue().doubleValue() / 100.0))
                );
                ((EntityVelocityUpdateS2CPacketAccessor) packet).setVelocityZ(
                    (int) (packet.getVelocityZ() * (horizontal.getValue().doubleValue() / 100.0))
                );
                break;
                
            case "Grim":
                // Cancel velocity and mark for packet completion
                if (!Sydney.SERVER_MANAGER.getSetbackTimer().hasTimeElapsed(100L)) {
                    return;
                }
                event.setCancelled(true);
                cancelVelocity = true;
                break;
                
            case "GrimV3":
                // Cancel velocity only when phased
                if (isPhased()) {
                    event.setCancelled(true);
                }
                break;
        }
    }
    
    private void handleExplosionPacket(PacketReceiveEvent event, ExplosionS2CPacket packet) {
        // Walls mode: only apply when phased
        if (mode.getValue().equalsIgnoreCase("Walls") && !isPhased()) {
            return;
        }
        
        // Check if explosion has player knockback
        if (packet.playerKnockback().isEmpty()) {
            return; // No knockback to modify
        }
        
        // Apply explosion reduction based on mode
        switch (mode.getValue()) {
            case "Normal":
            case "Walls":
                if (horizontal.getValue().doubleValue() == 0.0 && vertical.getValue().doubleValue() == 0.0) {
                    event.setCancelled(true);
                } else {
                    // Modify velocity using Vec3dAccessor
                    Vec3d knockback = packet.playerKnockback().get();
                    ((Vec3dAccessor) (Object) knockback).setX(
                        knockback.getX() * (horizontal.getValue().doubleValue() / 100.0)
                    );
                    ((Vec3dAccessor) (Object) knockback).setY(
                        knockback.getY() * (vertical.getValue().doubleValue() / 100.0)
                    );
                    ((Vec3dAccessor) (Object) knockback).setZ(
                        knockback.getZ() * (horizontal.getValue().doubleValue() / 100.0)
                    );
                }
                break;
                
            case "Grim":
                if (!Sydney.SERVER_MANAGER.getSetbackTimer().hasTimeElapsed(100L)) {
                    return;
                }
                event.setCancelled(true);
                cancelVelocity = true;
                break;
                
            case "GrimV3":
                if (isPhased()) {
                    event.setCancelled(true);
                }
                break;
        }
        
        // Play explosion sound if cancelled (fix for 1.19+)
        if (event.isCancelled()) {
            mc.executeSync(() -> {
                mc.world.playSound(
                    packet.center().getX(), 
                    packet.center().getY(), 
                    packet.center().getZ(),
                    packet.explosionSound().value(),
                    SoundCategory.BLOCKS,
                    4.0f,
                    (1.0f + (mc.world.random.nextFloat() - mc.world.random.nextFloat()) * 0.2f) * 0.7f,
                    false
                );
            });
        }
    }
    
    private void handleFishhookPacket(PacketReceiveEvent event, EntityStatusS2CPacket packet) {
        // Cancel fishing rod pull
        if (packet.getStatus() == EntityStatuses.PULL_HOOKED_ENTITY) {
            Entity entity = packet.getEntity(mc.world);
            if (entity instanceof FishingBobberEntity hook && hook.getHookedEntity() == mc.player) {
                event.setCancelled(true);
            }
        }
    }
    
    /**
     * Handle bundle packets - critical for Grim AC detection bypass!
     * Bundle packets contain multiple packets (velocity + explosion) combined
     * We handle them by processing each packet individually
     */
    private void handleBundlePacket(PacketReceiveEvent event, BundleS2CPacket bundlePacket) {
        boolean modified = false;
        
        for (net.minecraft.network.packet.Packet<?> packet : bundlePacket.getPackets()) {
            // Handle explosion in bundle
            if (packet instanceof ExplosionS2CPacket explosionPacket && explosion.getValue()) {
                // Play explosion sound (critical for 1.19+)
                mc.executeSync(() -> {
                    mc.world.playSound(
                        explosionPacket.center().getX(),
                        explosionPacket.center().getY(),
                        explosionPacket.center().getZ(),
                        explosionPacket.explosionSound().value(),
                        SoundCategory.BLOCKS,
                        4.0f,
                        (1.0f + (mc.world.random.nextFloat() - mc.world.random.nextFloat()) * 0.2f) * 0.7f,
                        false
                    );
                });
                
                // Apply explosion velocity modification
                if (explosionPacket.playerKnockback().isPresent()) {
                    if (mode.getValue().equalsIgnoreCase("Walls") && !isPhased()) {
                        continue;
                    }
                    
                    switch (mode.getValue()) {
                        case "Normal":
                        case "Walls":
                            if (horizontal.getValue().doubleValue() != 0.0 || vertical.getValue().doubleValue() != 0.0) {
                                Vec3d knockback = explosionPacket.playerKnockback().get();
                                ((Vec3dAccessor) (Object) knockback).setX(
                                    knockback.getX() * (horizontal.getValue().doubleValue() / 100.0)
                                );
                                ((Vec3dAccessor) (Object) knockback).setY(
                                    knockback.getY() * (vertical.getValue().doubleValue() / 100.0)
                                );
                                ((Vec3dAccessor) (Object) knockback).setZ(
                                    knockback.getZ() * (horizontal.getValue().doubleValue() / 100.0)
                                );
                                modified = true;
                            }
                            break;
                            
                        case "Grim":
                            if (Sydney.SERVER_MANAGER.getSetbackTimer().hasTimeElapsed(100L)) {
                                cancelVelocity = true;
                                modified = true;
                            }
                            break;
                            
                        case "GrimV3":
                            if (isPhased()) {
                                modified = true;
                            }
                            break;
                    }
                }
            }
            // Handle velocity in bundle
            else if (packet instanceof EntityVelocityUpdateS2CPacket velocityPacket && knockback.getValue()) {
                if (velocityPacket.getEntityId() == mc.player.getId()) {
                    // Walls mode check
                    if (mode.getValue().equalsIgnoreCase("Walls")) {
                        if (!isPhased() && (!wallsTrapped.getValue() || !isWallsTrapped())) {
                            continue;
                        }
                        
                        if (wallsGroundOnly.getValue() && !Sydney.POSITION_MANAGER.isServerOnGround()) {
                            continue;
                        }
                    }
                    
                    // Apply velocity reduction
                    switch (mode.getValue()) {
                        case "Normal":
                        case "Walls":
                            if (horizontal.getValue().doubleValue() != 0.0 || vertical.getValue().doubleValue() != 0.0) {
                                ((EntityVelocityUpdateS2CPacketAccessor) velocityPacket).setVelocityX(
                                    (int) (velocityPacket.getVelocityX() * (horizontal.getValue().doubleValue() / 100.0))
                                );
                                ((EntityVelocityUpdateS2CPacketAccessor) velocityPacket).setVelocityY(
                                    (int) (velocityPacket.getVelocityY() * (vertical.getValue().doubleValue() / 100.0))
                                );
                                ((EntityVelocityUpdateS2CPacketAccessor) velocityPacket).setVelocityZ(
                                    (int) (velocityPacket.getVelocityZ() * (horizontal.getValue().doubleValue() / 100.0))
                                );
                                modified = true;
                            }
                            break;
                            
                        case "Grim":
                            if (Sydney.SERVER_MANAGER.getSetbackTimer().hasTimeElapsed(100L)) {
                                cancelVelocity = true;
                                modified = true;
                            }
                            break;
                            
                        case "GrimV3":
                            if (isPhased()) {
                                modified = true;
                            }
                            break;
                    }
                }
            }
        }
        
        // Note: We modify packets in-place since bundle iteration allows it
        // No need to cancel the entire bundle
    }
    
    private void sendGrimCompletionPackets() {
        // Use server rotations for accurate packet sending
        float yaw = Sydney.ROTATION_MANAGER.getServerYaw();
        float pitch = Sydney.ROTATION_MANAGER.getServerPitch();
        
        // If actively rotating, use rotation values
        if (Sydney.ROTATION_MANAGER.isRotating()) {
            yaw = Sydney.ROTATION_MANAGER.getRotationYaw();
            pitch = Sydney.ROTATION_MANAGER.getRotationPitch();
        }
        
        // Send position packet
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
            mc.player.getX(),
            mc.player.getY(),
            mc.player.getZ(),
            yaw,
            pitch,
            mc.player.isOnGround(),
            mc.player.horizontalCollision
        ));
        
        // Send block break stop packet (critical for Grim)
        BlockPos blockPos = mc.player.isCrawling() ? mc.player.getBlockPos() : mc.player.getBlockPos().up();
        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
            PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK,
            blockPos,
            Direction.DOWN
        ));
    }
    
    @SubscribeEvent
    public void onPushEntity(PushEntityEvent event) {
        if (pushEntities.getValue() && event.getPushed().equals(mc.player)) {
            event.setCancelled(true);
        }
    }
    
    @SubscribeEvent
    public void onPushOutOfBlocks(PushOutOfBlocksEvent event) {
        if (pushBlocks.getValue()) {
            event.setCancelled(true);
        }
    }
    
    @SubscribeEvent
    public void onPushFluids(PushFluidsEvent event) {
        if (pushLiquids.getValue()) {
            event.setCancelled(true);
        }
    }
    
    /**
     * Checks if player is phased (inside a non-replaceable block)
     */
    private boolean isPhased() {
        return EntityUtils.getAllInBox(mc.player.getBoundingBox()).stream()
                .anyMatch(blockPos -> !mc.world.getBlockState(blockPos).isReplaceable());
    }
    
    /**
     * Checks if player head is trapped (for walls mode)
     */
    private boolean isWallsTrapped() {
        BlockPos headPos = mc.player.getBlockPos().up(mc.player.isCrawling() ? 1 : 2);
        return !mc.world.getBlockState(headPos).isReplaceable();
    }
}
