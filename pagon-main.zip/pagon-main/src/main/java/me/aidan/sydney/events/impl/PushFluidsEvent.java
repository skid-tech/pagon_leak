package me.aidan.sydney.events.impl;

import me.aidan.sydney.events.Event;

/**
 * Event fired when player is pushed by fluids (water/lava)
 */
public class PushFluidsEvent extends Event {
    
}
