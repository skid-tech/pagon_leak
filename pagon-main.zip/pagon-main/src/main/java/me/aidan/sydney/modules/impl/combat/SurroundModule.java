package me.aidan.sydney.modules.impl.combat;

import me.aidan.sydney.Sydney;
import me.aidan.sydney.events.SubscribeEvent;
import me.aidan.sydney.events.impl.PacketReceiveEvent;
import me.aidan.sydney.events.impl.PlayerJumpEvent;
import me.aidan.sydney.events.impl.PlayerMineEvent;
import me.aidan.sydney.events.impl.PlayerUpdateEvent;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;
import me.aidan.sydney.modules.impl.movement.HitboxDesyncModule;
import me.aidan.sydney.modules.impl.movement.SpeedModule;
import me.aidan.sydney.modules.impl.movement.StepModule;
import me.aidan.sydney.settings.impl.BooleanSetting;
import me.aidan.sydney.settings.impl.ModeSetting;
import me.aidan.sydney.settings.impl.NumberSetting;
import me.aidan.sydney.utils.minecraft.HoleUtils;
import me.aidan.sydney.utils.minecraft.InventoryUtils;
import me.aidan.sydney.utils.minecraft.PositionUtils;
import me.aidan.sydney.utils.minecraft.WorldUtils;
import me.aidan.sydney.utils.rotations.RotationUtils;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.BundleS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@RegisterModule(name = "Surround", description = "Automatically places blocks at your feet to prevent crystal damage.", category = Module.Category.COMBAT)
public class SurroundModule extends Module {
    public ModeSetting anticheat = new ModeSetting("AntiCheat", "The anticheat profile that placements will be adapted for.", "Grim", new String[]{"Vanilla", "Grim", "GrimV3"});
    public ModeSetting autoSwitch = new ModeSetting("Switch", "The mode that will be used for automatically switching to necessary items.", "Silent", InventoryUtils.SWITCH_MODES);
    public ModeSetting timing = new ModeSetting("Timing", "The timing that will be used in replacing broken surround blocks.", "Sequential", new String[]{"Vanilla", "Sequential"});
    public NumberSetting limit = new NumberSetting("Limit", "The maximum number of blocks that can be placed per tick group.", 4, 1, 20);
    public NumberSetting shiftTicks = new NumberSetting("ShiftTicks", "The number of blocks to place per tick.", 2, 1, 10);
    public NumberSetting shiftDelay = new NumberSetting("ShiftDelay", "The delay in ms between each block placement interval.", 50.0, 0.0, 500.0);
    public NumberSetting range = new NumberSetting("Range", "The maximum range at which the blocks will be placed at.", 5.0, 0.0, 12.0);

    
    public BooleanSetting await = new BooleanSetting("Await", "Waits for blocks to be registered by the client before placing on them.", false);
    public BooleanSetting rotate = new BooleanSetting("Rotate", "Whether or not you should rotate when you place blocks.", true);
    public BooleanSetting strictDirection = new BooleanSetting("StrictDirection", "Only places using directions that face you.", false);
    public BooleanSetting crystalDestruction = new BooleanSetting("CrystalDestruction", "Destroys any crystals that interfere with block placement.", true);
    public BooleanSetting center = new BooleanSetting("Center", "Puts you in the center of the block when you surround.", false);
    public BooleanSetting floor = new BooleanSetting("Floor", "Places blocks under your feet as well.", true);
    public BooleanSetting support = new BooleanSetting("Support", "Creates a floor for the surround if there is none.", true);
    public BooleanSetting extension = new BooleanSetting("Extension", "Extends the surround if there are entities obstructing block placement.", true);
    public BooleanSetting mineExtend = new BooleanSetting("MineExtend", "Extends surround if a block is being mined.", true);
    public BooleanSetting whileEating = new BooleanSetting("WhileEating", "Places blocks normally while eating.", true);
    
    public BooleanSetting prePlaceExplosion = new BooleanSetting("PrePlace-Explosions", "Pre places before explosions.", true);
    public BooleanSetting prePlaceTick = new BooleanSetting("PrePlace-Tick", "Pre places before crystal spawns.", true);

    public BooleanSetting selfDisable = new BooleanSetting("SelfDisable", "Toggles off the module once it is finished with placing.", false);
    public BooleanSetting jumpDisable = new BooleanSetting("JumpDisable", "Toggles off the module whenever your Y level changes.", true);
    public BooleanSetting itemDisable = new BooleanSetting("ItemDisable", "Toggles off the module whenever you run out of items to place with.", true);

    public BooleanSetting stepToggle = new BooleanSetting("StepToggle", "Toggles the step module when you surround.", false);
    public BooleanSetting speedToggle = new BooleanSetting("SpeedToggle", "Toggles the speed module when you surround.", false);

    public BooleanSetting render = new BooleanSetting("Render", "Whether or not to render the place position.", true);

    private Set<BlockPos> surroundPositions = new HashSet<>();
    private List<BlockPos> placements = new ArrayList<>();
    private final Map<BlockPos, Long> packetTimes = new HashMap<>();
    private BlockPos lastPosition = null;
    private double prevY;

    private int blocksPlaced = 0;

    // Cached per-tick state (avoids redundant hotbar scans)
    private int cachedSlot = -1;
    private long lastPlacementTime = 0L;

    // Blocks we placed as supports that the client has not confirmed yet (Await)
    private final Set<BlockPos> awaitingConfirmation = new HashSet<>();

    // Blocks other players are actively mining (thread-safe: updated from the netty thread)
    private final Set<BlockPos> minedBlocks = ConcurrentHashMap.newKeySet();

    private static final Direction[] HORIZONTALS = new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
    private static final Direction[] SUPPORT_DEPENDENCIES = new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};

    @Override
    public void onEnable() {
        if (mc.player == null || mc.world == null) return;
        
        lastPosition = PositionUtils.getFlooredPosition(mc.player);
        prevY = mc.player.getY();

        if(stepToggle.getValue() && Sydney.MODULE_MANAGER.getModule(StepModule.class).isToggled()) 
            Sydney.MODULE_MANAGER.getModule(StepModule.class).setToggled(false);
        if(speedToggle.getValue() && Sydney.MODULE_MANAGER.getModule(SpeedModule.class).isToggled()) 
            Sydney.MODULE_MANAGER.getModule(SpeedModule.class).setToggled(false);
            
        if(center.getValue()) {
            mc.player.setPosition(
                lastPosition.getX() + 0.5, 
                mc.player.getY(), 
                lastPosition.getZ() + 0.5
            );
        }
    }

    @SubscribeEvent
    public void onPlayerJump(PlayerJumpEvent event) {
        if (jumpDisable.getValue()) {
            setToggled(false);
        }
    }

    @SubscribeEvent
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) return;
        
        // Jump disable check with fallDistance
        if (jumpDisable.getValue() && (mc.player.getY() - prevY > 0.5 || mc.player.fallDistance > 1.5f)) {
            setToggled(false);
            return;
        }

        if (!whileEating.getValue() && mc.player.isUsingItem()) return;
        
        blocksPlaced = 0;
        cachedSlot = -1;

        // Expire stale tracking data
        minedBlocks.removeIf(pos -> !mc.world.getBlockState(pos).isReplaceable());
        awaitingConfirmation.removeIf(pos -> !mc.world.getBlockState(pos).isReplaceable());

        // Find hardest block
        if (autoSwitch.getValue().equalsIgnoreCase("None") && !(mc.player.getMainHandStack().getItem() instanceof BlockItem)) {
            if (itemDisable.getValue()) {
                Sydney.CHAT_MANAGER.tagged("You are currently not holding any blocks.", getName());
                setToggled(false);
            }
            surroundPositions.clear();
            placements.clear();
            return;
        }

        int slot = InventoryUtils.findHardestBlock(0, 8);
        int previousSlot = mc.player.getInventory().selectedSlot;

        if (slot == -1) {
            if (itemDisable.getValue()) {
                Sydney.CHAT_MANAGER.tagged("No blocks could be found in your hotbar.", getName());
                setToggled(false);
            }
            surroundPositions.clear();
            placements.clear();
            return;
        }
        
        cachedSlot = slot;

        // Get surround positions
        surroundPositions = getSurroundPositions(mc.player);
        if (surroundPositions.isEmpty()) {
            return;
        }

        // Attack blocking crystals
        if (crystalDestruction.getValue()) {
            attackBlockingCrystals(new ArrayList<>(surroundPositions));
        }

        // Get placements from surround
        placements = getPlacementsFromSurround(new ArrayList<>(surroundPositions));
        if (placements.isEmpty()) {
            if (selfDisable.getValue()) setToggled(false);
            return;
        }

        // Support placement: create a floor for blocks that have no valid face to place against
        if (support.getValue()) {
            List<BlockPos> supportBlocks = new ArrayList<>();
            for (BlockPos block : new ArrayList<>(placements)) {
                Direction direction = WorldUtils.getDirection(block, effectiveStrictDirection());
                if (direction != null) continue;

                BlockPos supportPos = block.down();
                if (supportPos.getY() < mc.player.getBlockY() - 1) continue;
                if (!mc.world.getBlockState(supportPos).isReplaceable()) continue;
                if (!placements.contains(supportPos) && !supportBlocks.contains(supportPos)) {
                    supportBlocks.add(supportPos);
                }
            }
            placements.addAll(0, supportBlocks); // Add support blocks first
        }

        // Sort by Y level first (floor first), then by rotation delta from the server yaw.
        // This minimizes yaw changes between consecutive placements which keeps Grim's
        // rotation checks happy while still placing as fast as possible.
        sortPlacements();

        // Shift delay between placement intervals
        long now = System.currentTimeMillis();
        if (shiftDelay.getValue() > 0 && now - lastPlacementTime < shiftDelay.getValue().longValue()) return;

        // Effective per-tick limit. GrimV3 is far stricter with rapid interactions,
        // so it gets capped to the group limit instead of the raw shift ticks value.
        int maxPerTick = shiftTicks.getValue().intValue();
        if (isGrimV3()) maxPerTick = Math.min(maxPerTick, limit.getValue().intValue());

        // Switch to slot
        InventoryUtils.switchSlot(autoSwitch.getValue(), slot, previousSlot);

        // Place blocks with shift ticks - the iterator always advances so a position with no
        // valid direction can never stall the loop (this was a freeze bug in the old version)
        Iterator<BlockPos> iterator = placements.iterator();
        while (iterator.hasNext() && blocksPlaced < maxPerTick) {
            BlockPos targetPos = iterator.next();

            if (tryPlace(targetPos, slot)) {
                blocksPlaced++;
                iterator.remove();
            }
        }

        // Switch back
        InventoryUtils.switchBack(autoSwitch.getValue(), slot, previousSlot);

        // Sync server rotations after placing so Grim's movement prediction stays consistent
        if (blocksPlaced > 0 && rotate.getValue() && !anticheat.getValue().equalsIgnoreCase("Vanilla")) {
            Sydney.ROTATION_MANAGER.setRotationSilentSync();
        }

        if (blocksPlaced > 0) lastPlacementTime = now;
    }

    @SubscribeEvent
    public void onPacketReceive(PacketReceiveEvent event) {
        if (mc.player == null || mc.world == null) return;
        if (!timing.getValue().equalsIgnoreCase("Sequential")) return;

        // Handle bundle packets
        if (event.getPacket() instanceof BundleS2CPacket bundle) {
            for (var packet : bundle.getPackets()) {
                handlePacket(packet);
            }
        } else {
            handlePacket(event.getPacket());
        }
    }

    private void handlePacket(Object packet) {
        // Block update handling
        if (packet instanceof BlockUpdateS2CPacket blockUpdate) {
            BlockState blockState = blockUpdate.getState();
            BlockPos targetPos = blockUpdate.getPos();
            
            awaitingConfirmation.remove(targetPos);

            if (surroundPositions.contains(targetPos)) {
                if (blockState.isReplaceable() && mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), targetPos, ShapeContext.absent())) {
                    int slot = cachedSlot != -1 ? cachedSlot : InventoryUtils.findHardestBlock(0, 8);
                    if (slot == -1) return;
                    
                    if (tryPlace(targetPos, slot)) blocksPlaced++;
                } else if (isBlastResistant(blockState)) {
                    packetTimes.remove(targetPos);
                }
            }
        }

        // Too many placements check
        if (blocksPlaced > shiftTicks.getValue().intValue() * 2) {
            return;
        }

        // Explosion pre-place
        if (packet instanceof ExplosionS2CPacket explosion && prePlaceExplosion.getValue()) {
            BlockPos pos = BlockPos.ofFloored(
                    explosion.center().getX(),
                    explosion.center().getY(),
                    explosion.center().getZ()
            );
            if (surroundPositions.contains(pos)) {
                int slot = cachedSlot != -1 ? cachedSlot : InventoryUtils.findHardestBlock(0, 8);
                if (slot == -1) return;
                
                tryPlace(pos, slot);
            }
        }

        // Crystal spawn pre-place
        if (packet instanceof EntitySpawnS2CPacket spawn && 
            spawn.getEntityType().equals(EntityType.END_CRYSTAL) && 
            prePlaceTick.getValue()) {
                
            BlockPos crystalPos = BlockPos.ofFloored(spawn.getX(), spawn.getY(), spawn.getZ());
            for (BlockPos pos : surroundPositions) {
                if (pos.equals(crystalPos)) {
                    int slot = cachedSlot != -1 ? cachedSlot : InventoryUtils.findHardestBlock(0, 8);
                    if (slot == -1) return;
                    
                    tryPlace(pos, slot);
                    break;
                }
            }
        }
    }

    @SubscribeEvent
    public void onPlayerMine(PlayerMineEvent event) {
        minedBlocks.add(event.getPosition());
    }

    private boolean isGrimV3() {
        return anticheat.getValue().equalsIgnoreCase("GrimV3");
    }

    private boolean effectiveStrictDirection() {
        // Grim validates that the clicked face is actually visible and reachable from your
        // rotation - restricting to valid faces prevents placement rejections and flags.
        return strictDirection.getValue() || !anticheat.getValue().equalsIgnoreCase("Vanilla");
    }

    private void sortPlacements() {
        float serverYaw = Sydney.ROTATION_MANAGER.getServerYaw();
        double px = mc.player.getX();
        double pz = mc.player.getZ();

        placements.sort(Comparator.comparingInt(Vec3i::getY).thenComparingDouble(pos -> {
            float targetYaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2((pos.getZ() + 0.5) - pz, (pos.getX() + 0.5) - px)) - 90.0);
            return Math.abs(MathHelper.wrapDegrees(targetYaw - serverYaw));
        }));
    }

    /**
     * Attempts to place a block at the given position. Returns whether a placement packet
     * was actually sent.
     */
    private boolean tryPlace(BlockPos pos, int slot) {
        BlockState state = mc.world.getBlockState(pos);
        if (!state.isReplaceable()) return false;

        Direction direction = WorldUtils.getDirection(pos, effectiveStrictDirection());
        if (direction == null) return false;

        // Await: defer placements whose supporting block has not been registered by the client yet
        if (await.getValue()) {
            for (Direction dependency : SUPPORT_DEPENDENCIES) {
                if (awaitingConfirmation.contains(pos.offset(dependency))) return false;
            }
        }

        boolean grimProfile = !anticheat.getValue().equalsIgnoreCase("Vanilla");

        if (grimProfile && rotate.getValue()) {
            // Grim profile: send one GCD-corrected snap rotation facing the exact position we are
            // clicking, then place without an internal rotation so the interaction is validated
            // against the rotation Grim just received. One valid rotation per placement.
            Sydney.ROTATION_MANAGER.packetRotate(RotationUtils.getRotations(pos.toCenterPos()));
            WorldUtils.placeBlock(pos, direction, Hand.MAIN_HAND, false, false, render.getValue());
        } else {
            WorldUtils.placeBlock(pos, direction, Hand.MAIN_HAND, rotate.getValue(), false, render.getValue());
        }

        packetTimes.put(pos, System.currentTimeMillis());
        if (await.getValue()) awaitingConfirmation.add(pos);

        return true;
    }

    private void attackBlockingCrystals(List<BlockPos> posList) {
        for (BlockPos pos : posList) {
            List<Entity> entities = mc.world.getOtherEntities(null, new Box(pos));
            Entity crystal = entities.stream()
                .filter(e -> e instanceof EndCrystalEntity)
                .findFirst()
                .orElse(null);
                
            if (crystal != null) {
                mc.player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(crystal, mc.player.isSneaking()));
                mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                return;
            }
        }
    }

    private List<BlockPos> getPlacementsFromSurround(List<BlockPos> surround) {
        List<BlockPos> placements = new ArrayList<>();
        
        for (BlockPos surroundPos : surround) {
            // Shift delay check
            Long placed = packetTimes.get(surroundPos);
            if (shiftDelay.getValue().floatValue() > 0.0f && placed != null && 
                System.currentTimeMillis() - placed < shiftDelay.getValue().floatValue()) {
                continue;
            }
            
            // Replaceable check
            if (!mc.world.getBlockState(surroundPos).isReplaceable()) {
                continue;
            }
            
            // Range check
            double dist = mc.player.squaredDistanceTo(surroundPos.toCenterPos());
            if (dist > MathHelper.square(range.getValue().doubleValue())) {
                continue;
            }

            // Can place check
            HitboxDesyncModule module = Sydney.MODULE_MANAGER.getModule(HitboxDesyncModule.class);
            if (WorldUtils.isPlaceable(surroundPos, module.isToggled() && !module.close.getValue())) {
                placements.add(surroundPos);
            }
        }
        
        return placements;
    }

    private Set<BlockPos> getSurroundPositions(net.minecraft.entity.player.PlayerEntity player) {
        // HoleUtils handles extension, floor and hitbox desync correctly (the old custom
        // implementation rounded Y instead of flooring it which surrounded the wrong block)
        HashSet<BlockPos> surroundBlocks = HoleUtils.getFeetPositions(player, extension.getValue(), floor.getValue(), false);
        
        // Mine extend: reinforce blocks that other players are actively mining.
        // Uses real mine tracking from PlayerMineEvent instead of a hardness check
        // that incorrectly flagged every soft block (dirt, grass...) as being mined.
        if (mineExtend.getValue() && !minedBlocks.isEmpty()) {
            List<BlockPos> playerBlocks = getPlayerBlocks(player);
            Set<BlockPos> extendBlocks = new HashSet<>();
            
            for (BlockPos surroundPos : surroundBlocks) {
                if (!minedBlocks.contains(surroundPos)) continue;
                
                for (Direction direction : HORIZONTALS) {
                    BlockPos blockerPos = surroundPos.offset(direction);
                    if (playerBlocks.contains(blockerPos)) continue;
                    if (surroundBlocks.contains(blockerPos)) continue;
                    extendBlocks.add(blockerPos);
                }
            }
            
            surroundBlocks.addAll(extendBlocks);
        }
        
        return surroundBlocks;
    }

    private List<BlockPos> getPlayerBlocks(net.minecraft.entity.player.PlayerEntity entity) {
        BlockPos playerPos = PositionUtils.getFlooredPosition(entity);
        List<BlockPos> playerBlocks = new ArrayList<>();
        
        if (extension.getValue()) {
            playerBlocks.addAll(getAllInBox(entity.getBoundingBox(), playerPos));
        } else {
            playerBlocks.add(playerPos);
        }
        
        return playerBlocks;
    }

    // Better-surround's getAllInBox implementation
    private static List<BlockPos> getAllInBox(Box box, BlockPos pos) {
        List<BlockPos> intersections = new ArrayList<>();
        for (int x = (int) Math.floor(box.minX); x < Math.ceil(box.maxX); x++) {
            for (int z = (int) Math.floor(box.minZ); z < Math.ceil(box.maxZ); z++) {
                intersections.add(new BlockPos(x, pos.getY(), z));
            }
        }
        return intersections;
    }

    private boolean isBlastResistant(BlockState state) {
        return state.getBlock() == Blocks.OBSIDIAN ||
               state.getBlock() == Blocks.BEDROCK ||
               state.getBlock() == Blocks.RESPAWN_ANCHOR ||
               state.getBlock() == Blocks.ENDER_CHEST ||
               state.getBlock() == Blocks.CRYING_OBSIDIAN ||
               state.getBlock() == Blocks.NETHERITE_BLOCK ||
               state.getBlock() == Blocks.ANCIENT_DEBRIS ||
               state.getBlock() == Blocks.ENCHANTING_TABLE ||
               state.getBlock() == Blocks.ANVIL;
    }

    @Override
    public void onDisable() {
        lastPosition = null;
        surroundPositions.clear();
        placements.clear();
        packetTimes.clear();
        awaitingConfirmation.clear();
        minedBlocks.clear();
        cachedSlot = -1;
        blocksPlaced = 0;
    }

    @Override
    public String getMetaData() {
        return String.valueOf(placements.size());
    }
}
