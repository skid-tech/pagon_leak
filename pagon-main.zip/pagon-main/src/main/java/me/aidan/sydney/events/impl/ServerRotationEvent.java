package me.aidan.sydney.events.impl;

import lombok.Getter;
import lombok.Setter;
import me.aidan.sydney.events.Event;

@Getter @Setter
public class ServerRotationEvent extends Event {
    private float yaw = Float.NaN;
    private float pitch = Float.NaN;
}
