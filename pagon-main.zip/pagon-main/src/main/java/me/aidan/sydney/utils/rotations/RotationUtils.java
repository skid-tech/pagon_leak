package me.aidan.sydney.utils.rotations;

import me.aidan.sydney.Sydney;
import me.aidan.sydney.utils.IMinecraft;
import me.aidan.sydney.utils.system.MathUtils;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.VoxelShape;

public class RotationUtils implements IMinecraft {
    public static float[] getRotations(Entity entity) {
        return getRotations(entity.getX(), entity.getY() + entity.getEyeHeight(entity.getPose()) / 2.0, entity.getZ());
    }

    public static float[] getRotations(Vec3d vec3d) {
        return getRotations(vec3d.x, vec3d.y, vec3d.z);
    }

    public static float[] getRotations(double x, double y, double z) {
        return getRotations(mc.player, x, y, z);
    }

    public static float[] getRotations(Entity entity, double x, double y, double z) {
        Vec3d vec3d = entity.getPos().add(0, entity.getEyeHeight(entity.getPose()), 0);

        double deltaX = x - vec3d.x;
        double deltaY = (y - vec3d.y) * -1.0;
        double deltaZ = z - vec3d.z;

        double distance = MathHelper.sqrt((float) (deltaX * deltaX + deltaZ * deltaZ));

        float yaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0);
        float pitch = (float) MathHelper.clamp(MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(deltaY, distance))), -90f, 90f);

        return new float[]{yaw + (((float) Math.random() - 0.5f) * 4), pitch + (((float) Math.random() - 0.5f) * 4)};
    }

    public static float[] getRotations(Direction direction) {
        return switch (direction) {
            case DOWN -> new float[]{mc.player.getYaw(), 90.0f};
            case UP -> new float[]{mc.player.getYaw(), -90.0f};
            case NORTH -> new float[]{180.0f, mc.player.getPitch()};
            case SOUTH -> new float[]{0.0f, mc.player.getPitch()};
            case WEST -> new float[]{90.0f, mc.player.getPitch()};
            case EAST -> new float[]{-90.0f, mc.player.getPitch()};
        };
    }

    /**
     * Calculate rotations from source to destination position
     * Based on Shoreline's implementation for accurate targeting
     */
    public static float[] getRotationsTo(Vec3d src, Vec3d dest) {
        float yaw = (float) (Math.toDegrees(Math.atan2(dest.subtract(src).z,
                dest.subtract(src).x)) - 90);
        float pitch = (float) Math.toDegrees(-Math.atan2(dest.subtract(src).y,
                Math.hypot(dest.subtract(src).x, dest.subtract(src).z)));
        return new float[] {
                MathHelper.wrapDegrees(yaw),
                MathHelper.wrapDegrees(pitch)
        };
    }

    /**
     * Smooth rotation transition for more human-like movement
     * Prevents instant snapping that triggers anticheats
     */
    public static float[] smooth(float[] target, float[] previous, float rotationSpeed) {
        float speed = (1.0f - (MathHelper.clamp(rotationSpeed / 100.0f, 0.1f, 0.9f))) * 10.0f;

        float[] rotations = new float[2];

        rotations[0] = previous[0] + (float) (-getAngleDifference(previous[0], target[0]) / speed);
        rotations[1] = previous[1] + (-(previous[1] - target[1]) / speed);

        // Force pitch to be in between -90 and 90 (instant AC-ban on some anticheats)
        rotations[1] = MathHelper.clamp(rotations[1], -90.0f, 90.0f);

        return rotations;
    }

    /**
     * Get the difference between two yaw angles
     * Properly handles angle wrapping for accurate calculations
     */
    public static double getAngleDifference(float client, float yaw) {
        return ((client - yaw) % 360.0 + 540.0) % 360.0 - 180.0;
    }

    /**
     * Gets the difference between two pitch angles
     * 
     * @param client the current pitch value
     * @param pitch  the target pitch value
     * @return the difference between the two angles
     */
    public static double getAnglePitchDifference(float client, float pitch) {
        return ((client - pitch) % 180.0 + 270.0) % 180.0 - 90.0;
    }

    /**
     * Get rotation vector from pitch and yaw
     * Used for raycasting and look direction calculations
     * Critical for proper aiming on advanced anticheats
     */
    public static Vec3d getRotationVector(float pitch, float yaw) {
        float f = pitch * ((float) Math.PI / 180.0f);
        float g = -yaw * ((float) Math.PI / 180.0f);
        float h = MathHelper.cos(g);
        float i = MathHelper.sin(g);
        float j = MathHelper.cos(f);
        float k = MathHelper.sin(f);
        return new Vec3d(i * j, -k, h * j);
    }

    /**
     * Calculate yaw rotation needed to face a specific direction
     */
    public static float getYaw(Vec3d direction) {
        return (float) Math.toDegrees(Math.atan2(direction.z, direction.x)) - 90.0f;
    }

    /**
     * Calculate pitch rotation needed to face a specific direction
     */
    public static float getPitch(Vec3d direction) {
        double xz = Math.sqrt(direction.x * direction.x + direction.z * direction.z);
        return (float) -Math.toDegrees(Math.atan2(direction.y, xz));
    }

    /**
     * Calculate look distance to a specific rotation
     * Used to determine how far we need to turn
     */
    public static double lookDistanceTo(float yaw, float pitch) {
        double yawChange = Math.abs(yaw - mc.player.getYaw());
        double pitchChange = Math.abs(pitch - mc.player.getPitch());
        return Math.sqrt(yawChange * yawChange + pitchChange * pitchChange);
    }

    /**
     * Set rotation through rotation manager
     */
    public static void setRotation(float[] rotation) {
        Sydney.ROTATION_MANAGER.rotate(rotation[0], rotation[1], 100);
    }

    /**
     * Set rotation with priority
     */
    public static void setRotation(float[] rotation, int priority) {
        Sydney.ROTATION_MANAGER.rotate(rotation[0], rotation[1], priority);
    }

    /**
     * Set rotation with yaw and pitch
     */
    public static void setRotation(float yaw, float pitch) {
        Sydney.ROTATION_MANAGER.rotate(yaw, pitch, 100);
    }

    /**
     * Set rotation with priority
     */
    public static void setRotation(float yaw, float pitch, int priority) {
        Sydney.ROTATION_MANAGER.rotate(yaw, pitch, priority);
    }

    /**
     * Set rotation object directly
     */
    public static void setRotation(Rotation rotation) {
        Sydney.ROTATION_MANAGER.rotate(rotation.getYaw(), rotation.getPitch(), rotation.getPriority());
    }

    /**
     * Get block rotations for a specific facing direction
     */
    public static float[] getBlockRotations(BlockPos pos, Direction facing) {
        if (facing == null) return null;
        return getBlockRotations(pos, facing, mc.player);
    }

    /**
     * Get block rotations from entity perspective
     */
    public static float[] getBlockRotations(BlockPos pos, Direction facing, Entity from) {
        Vec3d hitVec = pos.toCenterPos().add(new Vec3d(facing.getUnitVector()).multiply(0.5));
        return getRotationsTo(from.getEyePos(), hitVec);
    }

    /**
     * Get rotations with block state for accurate collision shape
     */
    public static float[] getRotations(BlockPos pos, Direction facing, Entity from, 
                                       ClientWorld world, BlockState state) {
        VoxelShape shape = state.getCollisionShape(world, pos);
        Box bb = !shape.isEmpty() ? shape.getBoundingBox() : new Box(0, 0, 0, 1, 1, 1);

        double x = pos.getX() + (bb.minX + bb.maxX) / 2.0;
        double y = pos.getY() + (bb.minY + bb.maxY) / 2.0;
        double z = pos.getZ() + (bb.minZ + bb.maxZ) / 2.0;

        if (facing != null) {
            x += facing.getOffsetX() * ((bb.minX + bb.maxX) / 2.0);
            y += facing.getOffsetY() * ((bb.minY + bb.maxY) / 2.0);
            z += facing.getOffsetZ() * ((bb.minZ + bb.maxZ) / 2.0);
        }

        return getRotations(from, x, y, z);
    }

    /**
     * Get block rotations with accurate calculations
     */
    public static float[] getBlockRotations(double x, double y, double z, 
                                            double fromX, double fromY, double fromZ) {
        double xDiff = x - fromX;
        double yDiff = y - fromY;
        double zDiff = z - fromZ;
        double dist = MathHelper.sqrt((float) (xDiff * xDiff + zDiff * zDiff));

        float yaw = (float) (Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) (-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));

        return new float[]{fixYaw(yaw), pitch};
    }

    /**
     * Fix yaw to prevent 360 degree jumps that flag anticheats
     * Critical for Grim compatibility
     * NOTE: This method calculates the proper delta but returns original yaw
     * The delta calculation is for validation, not modification
     */
    public static float fixYaw(float yaw) {
        float prevYaw = Sydney.ROTATION_MANAGER.getServerYaw();
        float diff = yaw - prevYaw;

        if (diff < -180.0f || diff > 180.0f) {
            float round = Math.round(Math.abs(diff / 360.0f));
            diff = diff < 0.0f ? diff + 360.0f * round : diff - (360.0f * round);
        }
        return yaw; // Return original yaw, not modified - Kami behavior
    }

    /**
     * Perform silent rotation via packet without visual change
     */
    public static void doSilentRotate(Rotation rotation) {
        Sydney.ROTATION_MANAGER.setRotationSilent(rotation.getYaw(), rotation.getPitch());
    }

    /**
     * Perform silent rotation with float array
     */
    public static void doSilentRotate(float[] rotation) {
        Sydney.ROTATION_MANAGER.setRotationSilent(rotation[0], rotation[1]);
    }

    /**
     * Sync client rotation to server
     * Required for Grim rotation-based movement checks
     */
    public static void silentSync() {
        Sydney.ROTATION_MANAGER.setRotationSilentSync();
    }

    /**
     * Rotate to block position
     */
    public static void doRotate(BlockPos pos) {
        float[] rots = getRotationsTo(mc.player.getEyePos(), pos.toCenterPos());
        if (rots != null) {
            setRotation(rots);
        }
    }

    /**
     * Rotate to block position with direction
     */
    public static void doRotate(BlockPos pos, Direction direction) {
        float[] rots = getBlockRotations(pos, direction);
        if (rots != null) {
            setRotation(rots);
        }
    }

    /**
     * Silent rotate to block with direction
     */
    public static void doSilentRotate(BlockPos pos, Direction direction) {
        float[] rots = getBlockRotations(pos, direction);
        if (rots != null) {
            doSilentRotate(rots);
        }
    }

    /**
     * Get actual yaw considering rotation manager state
     */
    public static float getActualYaw() {
        if (Sydney.ROTATION_MANAGER.getRotation() != null) {
            return Sydney.ROTATION_MANAGER.getRotation().getYaw();
        }
        return mc.player.getYaw();
    }

    /**
     * Get actual pitch considering rotation manager state
     */
    public static float getActualPitch() {
        if (Sydney.ROTATION_MANAGER.getRotation() != null) {
            return Sydney.ROTATION_MANAGER.getRotation().getPitch();
        }
        return mc.player.getPitch();
    }

    /**
     * Packet rotate without queue
     */
    public static void packetRotate(float[] rots) {
        Sydney.ROTATION_MANAGER.packetRotate(rots[0], rots[1]);
    }

    /**
     * Packet rotate with yaw and pitch
     */
    public static void packetRotate(float yaw, float pitch) {
        Sydney.ROTATION_MANAGER.packetRotate(yaw, pitch);
    }
}
