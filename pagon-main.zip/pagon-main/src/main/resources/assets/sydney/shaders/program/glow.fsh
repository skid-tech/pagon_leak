#version 330 core

in vec2 texCoord;
in vec2 oneTexel;

uniform sampler2D DiffuseSampler;
uniform int ShapeMode;
uniform int GlowStrength;
uniform float GlowMultiplier;
uniform int GlowQuality;
uniform float FillOpacity;

out vec4 fragColor;

struct BlurResult {
    float strength;
    vec3 color;
};

BlurResult computeBlur() {
    int w = GlowQuality * GlowStrength;
    float alphaSum = 0.0;
    vec3 rgbSum = vec3(0.0);

    float stepSize = float(GlowQuality);
    float wFloat = float(w);

    for (float x = -wFloat; x <= wFloat; x += stepSize) {
        for (float y = -wFloat; y <= wFloat; y += stepSize) {
            vec2 offset = oneTexel * vec2(x, y);
            vec4 sample = texture(DiffuseSampler, texCoord + offset);
            float a = sample.a;

            alphaSum += a;
            rgbSum += sample.rgb * a;
        }
    }

    float normalization = float(((GlowStrength * GlowStrength) + GlowStrength) * 4);
    float blurStrength = clamp(alphaSum / normalization, 0.0, 1.0) * GlowMultiplier;

    vec3 blurColor = (alphaSum > 0.0) ? (rgbSum / alphaSum) : vec3(0.0);

    return BlurResult(blurStrength, blurColor);
}

void main() {
    vec4 center = texture(DiffuseSampler, texCoord);

    if (center.a > 0.0) {
        // Inside the shape
        if (ShapeMode == 1) discard; // Outline only mode

        vec4 finalColor = vec4(center.rgb, center.a * FillOpacity);

        if (GlowStrength > 0 && GlowMultiplier > 0.0) {
            BlurResult blur = computeBlur();
            finalColor = mix(finalColor, vec4(center.rgb, 1.0), GlowMultiplier - blur.strength);
        }

        fragColor = finalColor;
    } else {
        // Outside the shape
        if (ShapeMode == 0 || GlowStrength == 0) discard; // Fill only mode or no glow

        // Check for 1-pixel outline
        for (int dx = -1; dx <= 1; ++dx) {
            for (int dy = -1; dy <= 1; ++dy) {
                if (dx == 0 && dy == 0) continue;
                vec4 neighbor = texture(DiffuseSampler, texCoord + oneTexel * vec2(dx, dy));
                if (neighbor.a > 0.0) {
                    fragColor = vec4(neighbor.rgb, 1.0);
                    return;
                }
            }
        }

        // Compute glow effect
        BlurResult blur = computeBlur();
        if (blur.strength == 0.0) discard;

        fragColor = vec4(blur.color, blur.strength);
    }
}
